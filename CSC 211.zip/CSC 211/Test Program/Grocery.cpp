/* Name: Sangram Mathews
   Course: CSC 211
   Prof. D. Kalicharan
*/

/*
 Display a Main Menu below with Menu options and your       company heading. Also you name must be in the program
  A. Read from a file the Grocery Items ID, Name, Quantity and Price
  B. Calculate order the total for each item, Add them up for a grand total and calculate the tax (NYC is 8.875%)
  C. Write to an out file and Screen with the sorted output of 5 items, quantity, price and total for each item, sub-total, tax and grand total. (Just like a receipt you get from the store)
  D. Print out available inventory 
  E. Exit
*/


#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <vector>
#define MAX 100 // Maximum numbers in file
using namespace std;

// Defines structure to store order information
struct Order
{
int ID;
string name;
int quantity;
};  // End of Order

// Defines class to store grocery inventory
class GroceryInv
{
int ID;
int quantity;
double price;
public:
// Default constructor
GroceryInv()
{
ID = quantity = 0;
price = 0.0;
}

// Parameterized constructor
GroceryInv(int id, int qty, double pr)
{
ID = id;
quantity = qty;
price = pr;
}

// Getter functions
int getID()
{

return ID;

}
int getQuantity()
{

return quantity;

}
double getPrice()
{

return price;

}

// Setter function
void setQuantity(int qty)
{

quantity -= qty;

}

};  // End of class

// Function to return the index position of the parameter id
int getIDIndex(GroceryInv grocery[], int id)
{
// Loops till number of items in the inventory
for(int c = 0; c < 5; c++)
// Checks if parameter id is equals to current object id
if(id == grocery[c].getID())
// Returns the found position
return c;
// Returns -1 for not found
return -1;
}

// Writes report to file
void writeFile(vector <Order> orders, GroceryInv grocery[],
double totalEach[], double tax, double grandTotal)
{
// ofstream objects declared to write data from files
ofstream fWrite;

// Opens the file for writing
fWrite.open("Amount.txt");

// Checks if the file unable to open for writing display's error message and stop
if(!fWrite)
{
cout<<"\n ERROR: Unable to open the file for writing.";
exit(0);
}

// Loops till number of orders
for(int c = 0; c < orders.size(); c++)
{
int index = getIDIndex(grocery, orders.at(c).ID);
// Writes a record
fWrite<<" Quantity: "<<orders.at(c).quantity
<<"\n Price: $"<<grocery[index].getPrice()
<<"\n Ordered Quantity: "<<totalEach[c];
}

fWrite<<"\n Tax: "<<tax <<"\n Grand Total: $"<<grandTotal << endl;

// Close the file
fWrite.close();
}

// Function to calculate order details
void calculateOrders(vector <Order> orders, GroceryInv grocery[], double totalEach[],
double &tax, double &grandTotal)
{
// Loops till number of items in the inventory
for(int d = 0; d < 5; d++)
{
// Loops till number of orders
for(int c = 0; c < orders.size(); c++)
{
// Checks if order id is equals to inventory id
if(orders.at(c).ID == grocery[d].getID())
{
// Calculates total order for current id
totalEach[d] += orders.at(c).quantity;
// Update the quantity in the grocery inventory
grocery[d].setQuantity(orders.at(c).quantity);
// Calculates grand total
grandTotal = grandTotal + (grocery[c].getPrice() * orders.at(c).quantity);
}// End of if condition
}// End of inner for loop
}// End of outer for loop

// Calculates tax
tax = grandTotal * 0.08875;
}

// Function to display grocery inventory
void showGroceryInventory(GroceryInv grocery[])
{
cout<<"\n\n ******** After Order Status ******** ";
// Loops till number of items in the inventory
for(int c = 0; c < 5; c++)
cout<<"\n ID: "<<grocery[c].getID()<<"\n Quantity: "<<grocery[c].getQuantity()
<<"\n Price: $"<<grocery[c].getPrice();
}// End of function

// Function to read file contents and stores it in vector
void readFile(vector <Order> *orders, GroceryInv grocery[], string fileName)
{
int ID;
string name;
int quantity;
Order ord;

// ifstream objects declared to read data from files
ifstream fRead;

// Opens the file for reading
fRead.open(fileName.c_str());

// Checks if the file unable to open for reading display's error message and stop
if(!fRead)
{
cout<<"\n ERROR: Unable to open the file for reading.";
exit(0);
}// End of if condition

// Loops till end of the file
while(!fRead.eof())
{
// Reads a record
fRead>>ord.ID>>ord.name>>ord.quantity;
// Adds the record to vector
orders->push_back(ord);

}// End of while loop

// Close the file
fRead.close();
}// End of function

// Function to display menu, accept and return user choice
int menu()
{
int ch;
cout<<"\n\n *************** S&M Online Grocery Inventory *************** ";
cout<<"\n\t 1 - Read order. \n\t 2 - Calculate order total. \n\t 3 - Write order details. "
<<"\n\t 4 - Print Available Inventory. \n\t 5 - Exit. \n\t\t What is your choice? ";
cin>>ch;
return ch;
}

// main function definition
int main()
{
// Vector to store order details
vector <Order> orders;

// Creates an array to store grocery inventory
GroceryInv grocery[MAX];

double grandTotal = 0;
double totalEach[5] = {0};
double tax;

// Creates the object using parameterized constructor
grocery[0] = GroceryInv(1011, 100, 1.50);
grocery[1] = GroceryInv(1012, 150, 1.75);
grocery[2] = GroceryInv(1013, 200, 0.85);
grocery[3] = GroceryInv(1014, 80, 2.75);
grocery[4] = GroceryInv(1015, 155, 2.50);

// Loops till user choice is not 5
do
{
// Calls the function to get user choice
// Calls other functions based on return user choice
switch(menu())
{
case 1:
readFile(&orders, grocery, "Order1.txt");
break;
case 2:
calculateOrders(orders, grocery, totalEach, tax, grandTotal);
break;
case 3:
writeFile(orders, grocery, totalEach, tax, grandTotal);
break;
case 4:
showGroceryInventory(grocery);
break;
case 5:
exit(0);
default:
cout<<"\n Invalid Choice!!";
}
}while(1);// End of do - while lop
return 0;
}// End of main function