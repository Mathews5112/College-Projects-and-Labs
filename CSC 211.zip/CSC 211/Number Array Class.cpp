// Sangram Mathews
// CSC 211
// Programming challenge 10: Number Array Class 

#include <iostream>
using namespace std;

class array
{
private:
   double *ptr;
   int size;
public:
   array(int i)
       {ptr=new double[i];
       size=i;
       }
   ~array()
   {delete ptr;
   }
   void setnum(int i, double n)
       { *(ptr+i)=n;
        }
   double getnum(int i)
       {return *(ptr+i);
       }
   double average()
       {double sum=0;
       int i;
       for(i=0;i<size;i++)
          sum+=*(ptr+i);
       return sum/size;
       }
    double largest()
       {double l;
       int i;
       l=*ptr;
       for(i=1;i<size;i++)
          if(*(ptr+i)>l)
               l=*(ptr+i);
       return l;
       }
    double smallest()
       {double l;
       int i;
       l=*ptr;
       for(i=1;i<size;i++)
          if(*(ptr+i)<l)
               l=*(ptr+i);
       return l;
      }
};

int main()
{ int size,i;
   double num;
   cout<<"How many numbers do you have? ";
   cin>>size;
   array numbers(size);
   cout<<"Enter the numbers:\n";
   for(i=0;i<size;i++)
     {cout<<"Enter number"<<i+1<<": ";
      cin>>num;
      numbers.setnum(i,num);
     }
   cout<<"The array is :\n";
   for(i=0;i<size;i++)
     cout<<numbers.getnum(i)<<" ";
   cout<<endl;
   cout<<"The largest number is:"<<numbers.largest()<<endl;
   cout<<"The smallest number is:"<<numbers.smallest()<<endl;
   cout<<"The average is:"<<numbers.average()<<endl;

   return 0;
}