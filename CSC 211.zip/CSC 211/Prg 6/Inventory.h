// Inventory.h file
#include <iostream>
#include <string>
#ifndef INVENTORY_H
#define INVENTORY_H
using namespace std;

// inventory item  class declaration 
class Inventory
{

// variables for private member 
	private:
		int itemNumber;
		int quantity;
		double cost;
	        double totalCost;

// public member functions 
	public:

// default construtor 
		Inventory()
		{
			itemNumber = 0;
			quantity = 0;
			cost = 0;
			totalCost = 0;

		}
		// this can be called as quantity and cost have now been initialized.
		Inventory(int newItemNumber, int newQuantity, double newCost)
{
  itemNumber = newItemNumber;
  quantity = newQuantity;
  cost = newCost;
  setTotalCost(quantity, cost); 
}

// function assign values to variables 

		void setItemNumber(int i)
		{
			itemNumber = i ;
		}
		void setQuantity(int q)
		{
			quantity = q ;
		}
		void setCost(double c)
		{
			cost = c ;
		}
		void setTotalCost(int, double)
		{
			totalCost = quantity * cost;
		}

		int getItemNumber()
		{
			return itemNumber;
		}
		int getQuantity()
		{
			return quantity;
		}
		double getCost()
		{
			return cost;
		}
		double getTotalCost()
		{
			return totalCost;
		}
};
#endif