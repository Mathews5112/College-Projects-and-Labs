#include <iostream>
#include <string>
#include "Inventory.h"
using namespace std;

int main()
{
//Declare variables 
	int itemNumber;
	int quantity;
	double cost;
	double totalCost;
// prom user to enter the item number, quantity and cost of the item in the store. 

	cout << "Enter the Item Number: ";
	cin >> itemNumber;
	while (itemNumber < 0)
	{
		cout << "Please enter a positive value for the Item Number: ";
		cin >> itemNumber;
	}
	cout << "Enter the Quantity of the item: ";
	cin >> quantity;
	while (quantity < 0)
	{
		cout << "Please enter a positive value for the Quantity of the item: ";
		cin >> quantity;
	}
	cout << "Enter the Cost of the item: ";
	cin >> cost;
	while (cost < 0)
	{
		cout << "Please enter a positive value for the Cost of the item: ";
		cin >> cost;
	}
// inventory variables within the program assign to it. 
	Inventory information(itemNumber, quantity, cost);

	totalCost = information.getTotalCost();
	itemNumber = information.getItemNumber();
	cost = information.getCost();
	quantity = information.getQuantity();
// display values entered (item number, quantity and cost).
// display total cost of the item
	cout << "The Item Number is: " << itemNumber << endl;
	cout << "The Quantity is: " << quantity << endl;
	cout << "The Cost is: " << cost << endl;
	cout << "The Total Cost is: " << totalCost << endl;
	
	return 0;
}