// Sangram Mathews
// CSC 211
// Chapter 12
// Programming Challenge 6
// String Search

#include <iostream>
#include <string> //to work with strings
#include <fstream>
using namespace std;

int main()
{
    //declare accumulator to keep track of number of occurrences
    int occurenceNumber = 0;

    //declare string variables
    string fileName; //to store fileName from user
    string lineRead; //to get current line
    string toSearch; //to search for inside of file

    //define file stream object used for input only
    ifstream inputFile;

    //prompt user to enter filename
    //then read
    cout << "Please enter the name of the file you wish to read.\n";
    cin >> fileName;

    //open file
    inputFile.open(fileName);

    //display error message if error occurred while opening
    if(!inputFile){
        cout << "Error opening file, or file doesn't exist!";
        cout << "Try again!\n";
        //end program immediately if error
        return 0;
    }

    //prompt user to enter search string then read
    cout << "Enter the string to search inside file:\n";
    cin >> toSearch;

    //ignore the newline character left in keyboard buffer
    cin.ignore();

    //read file line by line until no more lines to read
    while(getline(inputFile, lineRead))
    {
        //search the current line if it includes
        //the string we are searching for, using
        //the .find() member function of strings
        //make sure that the occurrence is somewhere
        //within the length of the current line from file
        if(lineRead.find(toSearch, 0) < lineRead.length()){
            //if found, increment occurrences number
            occurenceNumber++;
            //also print the current line
            cout << lineRead << endl;
            }

    } //while loop ends here

    //print the total number of occurrences
    cout << toSearch << " appears " << occurenceNumber;
    cout << " time(s) inside this file.\n";

    //don't forget to close file
    inputFile.close();

    //return 0 to mark successful termination
    return 0;
}
