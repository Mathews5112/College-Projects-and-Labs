//Project 3
//Name: Sangram Mathews
//CSC 111 (1900)
//Prof. Yakov Genis
//This program displays the information about Joe's stock exchange with Acme software Inc.
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
  // Declare all the double variables and initialize them
  double sharesBought = 1000, stockPrice1 = 45.50, commission1, sharesSold = 1000, stockPrice2= 56.90, commission2;
  double totalvalue_sharesBought, totalvalue_sharesSold, totalSpent, netProfit;
  cout << "Joe's stock transanction program" <<endl;
  cout << "********************************" <<endl;
  
  // Compute total cost of shares bought
  totalvalue_sharesBought = sharesBought * stockPrice1;
  
  // Compute total cost of shares sold
  totalvalue_sharesSold = sharesSold * stockPrice2;

  // Compute commission1
  commission1 = totalvalue_sharesBought * 0.02;
  
  // Compute commission2
  commission2 = totalvalue_sharesSold * 0.02;
  
  // Calculate the total amount of money spent
  totalSpent = totalvalue_sharesBought + commission1 + commission2;
  
  // Calculate net profit
  netProfit = totalvalue_sharesSold - totalSpent;
  
  // Display result with setprecision
  cout << setprecision(2) << fixed;
  
  // Display Amount 
  cout << "Amount paid for the stock : $" << totalvalue_sharesBought <<endl;
  
  // Display commission1 
  cout << "Commission paid to broker for buying shares: $" << commission1 << endl;
  
  // Display stock
  cout << "Stock sold for : $" << totalvalue_sharesSold << endl;
  
  // Display commission2 
  cout << "Commission paid to broker for selling stock: $" << commission2 << endl;
  
  // Display profit 
  cout << "total profit earned: $" << netProfit << endl;

  return 0;

}