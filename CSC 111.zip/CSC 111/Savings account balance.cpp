// Extra Project 5
// Name: Sangram Mathews
// CSC 111 (1900)
// Prof. Yakov Genis

//Write a program that calculates the balance of a savings account at the end of a period of time. It should ask the user for the annual interest rate, the starting balance, and the number of months that have passed since the account was established. A loop should then iterate once for every month, performing the following:

//(A) Ask the user for the amount deposited into the account during the month. (Do not accept negative numbers.) This amount should be added to the balance.

//(B) Ask the user for the amount withdrawn from the account during the month. (Do not accept negative numbers.) This amount should be subtracted from the balance.

//(C) Calculate the monthly interest. The monthly interest rate is the annual interest rate divided by twelve. Multiply the monthly interest rate by the balance, and add the result to the balance.

//After the last iteration, the program should display the ending balance, the total amount of deposits, the total amount of withdrawals, and the total interest earned.

#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
  const int MONTHS = 12;
    
    float starting_balance,
          annual_interest_rate,
          amount_deposited,
          amount_withdrawn,

          interest_rate,
          monthly_interest_rate,
          
          balance,
          total_deposits,
          total_withdrawn,
          total_interest_earned;

    int months_since_established;

    cout << "\nEnter the annual interest rate on the account : ";
    while ((cin >> annual_interest_rate) && annual_interest_rate < 0)
    {
        cout << "Interest rate must be non-negative: ";
        
    }

    cout << "Enter starting balance: ";
    while ((cin >> starting_balance) && starting_balance < 0)
    {
        cout << "The balance must be greater than 0: ";
        
    }

    balance = starting_balance;

    cout << "Enter number of months passed since account "
         << "was established: ";
    while ((cin >> months_since_established) && 
             months_since_established < 0)
    {
        cout << "Number of months must be non-negative: ";
      
    }

    monthly_interest_rate = annual_interest_rate / MONTHS;

    for (int i = 0; i < months_since_established; i++)
    {
        cout << "Enter the amount deposited for month " 
             << (i + 1) << ": ";
        while ((cin >> amount_deposited) && 
                 amount_deposited < 0)
        {
            cout << "Deposits must be zero or greater. Please re-enter: " 
            << (i + 1) << ": ";
        }

        total_deposits += amount_deposited;
        balance += amount_deposited;

        if (balance < 0)
            break;

        cout << "Enter the amount withdrawn for month " 
             << (i + 1) << ": ";
        while ((cin >> amount_withdrawn) && 
                 amount_withdrawn < 0)
        {
            cout << "Withdrawals must be zero or greater. Please re-enter: " 
            << (i + 1) << ": ";
        }

        total_withdrawn += amount_withdrawn;
        balance -= amount_withdrawn;

        if (balance < 0)
            break;

        interest_rate = (monthly_interest_rate * balance);
        balance += interest_rate;

        if (balance < 0)
            break;

        total_interest_earned += (interest_rate);
    } // for loop end

    if(balance < 0)
    {
        cout << "I'm sorry, your account has been closed\n"; 
        cout << "due to having a negative balance." << endl;
    }
    else
    {
        cout << setprecision(2) << fixed << endl;
        cout << "Starting balance            = $" 
             << starting_balance << endl;

        cout << "Ending balance              = $" 
             << balance << endl;

        cout << "Total amount in deposits    = $" 
             << total_deposits << endl;

        cout << "Total amount in withdrawals = $" 
             << total_withdrawn << endl;

        cout << "Total interest earned       = $" 
             << total_interest_earned 
             << endl 
             << endl;
    }
    
    

    return 0;
}