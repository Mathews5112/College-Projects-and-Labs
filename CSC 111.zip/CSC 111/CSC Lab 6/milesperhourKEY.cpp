//This program inputs miles traveled and hours spent in travel
//It determines miles per hour

//Sangram Mathews

#include <iostream>
#include <iomanip>
using namespace std;

void mph(float miles, float hours, float milesHours);

int main()
{
  cout << fixed << showpoint << setprecision(2);
  float miles;         //miles traveled
  float hours;         //time in hours
  float milesPerHour;  //calculated miles per hour

  cout << "Please input the Miles traveled" << endl;
  cin >> miles;

  cout << "Please input the hours traveled" << endl;
  cin >> hours;

  mph(miles, hours, milesPerHour);

  return 0;

}

void mph(float miles, float hours, float milesHours)
{
  milesHours = miles / hours;
  cout << "Your speed is " << milesHours << " miles per hour" << endl;
}