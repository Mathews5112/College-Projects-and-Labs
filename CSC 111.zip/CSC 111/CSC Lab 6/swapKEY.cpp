// This program swaps the value of two integer numbers
// Sangram Mathews
#include<iostream>

using namespace std;
//prototype
void Swap(int &, int &);

int main()
{
	int number1, number2;

	cout << "Enter the first number then hit enter: " << endl;
  cin >> number1;
  cout << "Enter the second number then hit enter: " << endl;
	cin >> number2;
  cout << "Before swapping,\n the values are "
		<< number1 << " and " << number2 << endl;
	
  //function call
	Swap(number1, number2);

	cout << "After swapping,\n the values are "
		<< number1 << " and " << number2 << endl;

	return 0;
}

//definition
void Swap(int &n1, int& n2)
{
	int n3;


	n3 = n1;
	n1 = n2;
	n2 = n3;

}