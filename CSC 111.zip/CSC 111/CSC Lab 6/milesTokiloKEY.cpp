
// Sangram Mathews
// This program converts miles to kilometers
// and kilometers to miles
#include <iostream>
#include <iomanip>
#include <stdlib.h>
using namespace std;

float kilometersToMiles(float number1);
float milesToKilometers(float number2);

int main()
{
	float number1;
  float number2;
	int unit;

	cout << "This program will convert kilometers to miles, and miles to kilometers.\n";
	cout << "Please enter 1 if you would like to convert km to mi.\n";
	cout << "Please enter 2 if you would like to convert mi to km.\n";
  cout << "Please enter 3 if you want to quit the program \n";
	cin >> unit;
	if(unit == 1)
	{ 
    cout << "Please input the number you want to convert" <<endl;
    cin >> number1;
		float miles = kilometersToMiles(number1);
		cout << number1 << " kilometers is equal to " << miles << " miles.\n";
	}
	else if(unit == 2)
	{
    cout << "Please input the number you want to convert" << endl;
    cin >> number2;
		float kilometers = milesToKilometers(number2);
		cout << number2 << " miles is equal to " << kilometers << " kilometers.\n";
	}
  else if (unit == 3)
  {
    cout << "The program will now close" << endl;
    exit(3);
  }
}


float kilometersToMiles(float number)
{
	float miles = number * .621;
	return miles;
}

//********************************************************************************
// milesToKilometers
//
// Task: This function is given a float value, miles,
// and calculates and returns a new float, kilometers.
//
// Precondition: miles, which is a float, is entered.
// Postcondition: kilometers, which is a float, is returned.
//
//********************************************************************************

float milesToKilometers(float number)
{
	float kilometers = number * 1.61;
	return kilometers;
}