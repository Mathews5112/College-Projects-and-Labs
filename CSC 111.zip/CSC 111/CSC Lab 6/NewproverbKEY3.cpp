// This program will allow the user to input from the keyboard
// whether the last word to the following proverb should be party or country:
// "Now is the time for all good men to come to the aid of their _______"
// Inputting a 1 will use the word party. Any other number will use the word country.
//
// Sangram Mathews

#include <iostream>
#include <string>
using namespace std;


void writeProverb( string );

int main ()
{	
	string wordCode;

	cout << "Given the phrase:" << endl;
	cout << "Now is the time for all good men to come to the aid of their ___" << endl;
	cout << "Input a word to finish the sentence" << endl;
	cin  >> wordCode;
	cout << endl;
  writeProverb(wordCode);

	return 0;
}

void writeProverb (string word)
{
  
  cout << "Now is the time for all good men to come to the aid of their" << word << endl;
}