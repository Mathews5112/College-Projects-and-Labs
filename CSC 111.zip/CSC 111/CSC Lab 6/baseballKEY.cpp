// Sangram Mathews

#include <iostream>
#include <iomanip>
using namespace std;

unsigned getWins();
unsigned getLosses();
float calcPercentage( unsigned, unsigned );

int main() {
    std::cout << std::fixed << std::setprecision(2)
              << calcPercentage( getLosses(), getWins() );

    return 0;
}

unsigned getWins() 
{
    unsigned w;
    std::cout << "Please input the number of wins\n";
    std::cin >> w;
    return w;
}

unsigned getLosses() 
{
    unsigned l;
    std::cout << "Please input the number of losses\n";
    std::cin >> l;
    return l;
}

float calcPercentage( unsigned l, unsigned w ) 
{
  cout << "The percentage of winning is: " << endl;
    return ( static_cast<float>(w) / (w+l) ) * 100.0;
}
