// This program will determine the batting average of a player.
// The number of hits and at bats are set internally in the program.

// Sangram Mathews

#include <iostream>
using namespace std;

const int AT_BAT = 421;
const int HITS = 123;

int main()
{
	int batAvg;

	batAvg = AT_BAT / HITS;

	cout << "The batting average is " << batAvg << endl;
  

	return 0;
} 