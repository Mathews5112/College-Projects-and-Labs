// Extra Project 7
// Lo shu magic square
// Sangram Mathews
// CSC 111 (1900)
#include <iostream>
#include <iomanip>
using namespace std;

//globals
const int ROWS = 3, COL = 3;
void PopulateArray(int array[] [COL] , int rows);
int inputValidate();
void Sum(int array[] [COL], int rows);

int main()
{
    int Array[ROWS][COL];

    PopulateArray(Array, ROWS);
    for (int row = 0; row < ROWS; row++)
        {      
            for (int col = 0; col < COL; col++)
            {   
                cout << setw(4) << Array[row][col];
            }
            cout << endl;
        }

    Sum(Array, ROWS);


    
}

//populate array
void PopulateArray(int array[] [COL] , int rows)
{
    for (int row = 0; row < ROWS; row++)
    {   
        cout << "Enter a number for row " << row << endl;
        for (int col = 0; col < COL; col++)
        {   
            cout << " Column " << col << ": ";
            array[row][col] = inputValidate();
        }
        cout << endl;
    }
    cout << "Your grid was " << endl;

}

void Sum(int array[] [COL], int rows)
{
    int sum = 0;

    for (int rows = 0; rows < ROWS; rows++)
    {
        for (int col = 0; col < COL; col++)
        {
            sum += array[rows][col];
        }
    }

    if (sum % 3 == 0)
    {
        cout << "The sum of each row, each column, and each diagonal is the same.";
    }
    else
    {
        cout << "The grid is not magic.";
    }
    
}

int inputValidate()
{
    int num;
    while(!(cin >> num) || num > 9 || num < 1)
    {
        cout << "Number must be between 1 and nine.";
        cin.clear();
        cin.ignore(1200, '\n');

    }
    return num;
}