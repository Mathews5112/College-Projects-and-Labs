// Sangram Mathews

#include <iostream>
using namespace std;

int main()
{
	char letter = 'a';

	while (letter != 'x')
	{
		cout << "Please enter a letter" << endl;
    cout << "If you enter the letter 'x' the program will stop" << endl;
		cin >> letter;

		cout << "The letter you entered is " << letter << endl;
	}

	return 0;
}