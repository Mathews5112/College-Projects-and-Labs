 //3. This program performs a survey tally on beverages. The program should
 //prompt for the next person until a sentinel value of –1 is entered to terminate the program.
 //Each person participating in the survey should choose their favorite beverage from the
 //following list: 1. Coffee 2. Tea 3. Coke 4. Orange Juice

//Name: Sangram Mathews 

#include<iostream>
 
 using namespace std;
 int main()
 {

 //Declared variables integers set to 0 to begin.
 int selection = 0, 
 coffeeCount = 0, 
 teaCount = 0, 
 cokeCount = 0, 
 oJCount = 0;		

 // sentinal loop to repeat selection, to aggregate list until done
 while ( selection != -1)
 {
 cout << "1. Coffee 2. Tea 3. Coke 4. Orange Juice \n";
 cout << "Please input your favorite beverage, \n";
 cout << "Choose 1, 2, 3, or 4 from the above menu \n";
 cout << "or -1 to exit the program : \n";

 cin >> selection;

// Incrementing operator for whichever beverage is chosen.
 switch (selection)
 {
 	case 1 : 							
 		coffeeCount = ++coffeeCount; 	 // Increments Coffee if selected
         break;       					 // exits the switch
     case 2 : 							
     	teaCount = ++teaCount; 			 //Increments Tea if selected
         break;       					 //exits the switch
 	case 3 : 							
 		cokeCount = ++cokeCount;		 //Increments Coke if selected
         break;       					 //exits the switch
 	case 4 : 							
 		oJCount = ++oJCount; 			 //Increments Orange Juice if selected
         break;       					 //exits the switch
 	case -1 : 
 		break;       				 //exits the switch        
 }
 }

 // Outputs aggregate beverage count
 cout << "\nCoffee: " << coffeeCount;
 cout << "\nTea: " << teaCount;
 cout << "\nCoke: " << cokeCount;
 cout << "\nOrange Juice: " << oJCount;

 return 0;
 }