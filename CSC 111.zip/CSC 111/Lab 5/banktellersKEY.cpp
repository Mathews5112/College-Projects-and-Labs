// Option 3: Write a program that prompts the user for the number of tellers at
// Nation’s Bank in Hyatesville that worked each of the last three years. For
// each worker the program should ask for the number of days out sick for
// each of the last three years. The output should provide the number of
// tellers and the total number of days missed by all the tellers over the last
// three years.

// Name: Sangram Mathews

#include <iostream>
#include <list>
using namespace std;

int main() {
	 
	int          num_tellers;
	unsigned int sick_days = 0;
	
	cout << "How many tellers worked at Nation’s Bank during each of the last"
	        " three years ?\n";
	cin >> num_tellers;
	
	// can't have 0 or a negative number of tellers
	if (num_tellers < 1) {
		cerr << "That's not an valid information. Try an input of at least 1\n";
		return 1;
	}

	for ( int teller = 1 ; teller <= num_tellers ; teller++ ) {
		for ( int year = 1 ; year < 4 ; year++ ) {
			int days = 0;
			cout << "How many days was teller " << teller
			     << " out sick during year " << year << " ?\n";
			cin >> days;
			sick_days += days; 
		}
	} 
	
	cout << "\nThe " << num_tellers << " tellers were out sick for a total of "
	     << sick_days << " days during the last 3 years.\n";
	
	return 0;
}