// Project 4
// CSC 111 (1900)
// Name: Sangram Mathews
// Prof: Yakov Genis

#include <iostream>
using namespace std;
int main()
{ // Declare Variables
  int month, year;
  int days = 30;
  int leap_year_days = 29;

  // Ask user to enter the month
  cout << "Enter a month (1-12): ";
  cin >> month;
  // Display error message if the month is not
  // between 1-12
  if (month < 1 || month > 12)
    cout << "Month should be between 1 and 12" << endl;

  else 
  {
    // Ask the user to enter the year
    cout << "Enter a year: ";
    cin >> year;
    
    // Determine if the year is a leap year or not 
    if (year % 100 == 0 && year % 400 == 0 && month == 2)
    cout << leap_year_days << "days" << endl;

    else if (year % 100 != 0 && year % 4 == 0 && month == 2)
    cout << leap_year_days << "days" << endl; 

    else
    cout << days << "days" << endl;
  }

  return 0;

}