// Sangram Mathews
// Prof. Yakov Genis
// CSC 111 (1900)
// Fall 2020

// Project 6

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

//function prototype
void getJudgeData(double&);
bool isValid(double);
void calcScore(double&, double&, double&, double&, double&);
double findHighest(double&, double&, double&, double&, double&);
double findLowest(double&, double&, double&, double&, double&);




int main()
{
	double judgeScore1, judgeScore2, judgeScore3, judgeScore4, judgeScore5;
	getJudgeData(judgeScore1);
	getJudgeData(judgeScore2);
	getJudgeData(judgeScore3);
	getJudgeData(judgeScore4);
	getJudgeData(judgeScore5);
	calcScore(judgeScore1, judgeScore2, judgeScore3, judgeScore4, judgeScore5);

	return 0;
}





//function
void getJudgeData(double& judgeScore)
{
	
		static int count;
		count++;
		cout << "Enter a score between 0 & 10 for judge " << count << ": ";
			cin >> judgeScore;

		while(!isValid(judgeScore)) 
    {
			cout << "Invalid .....";
			cout << " enter a score between 0 & 10: ";
			cin >> judgeScore;
		}
		
}



//function: bool
bool isValid(double judgeScore ) 
{
	bool results = true;
	if (judgeScore < 0 || judgeScore > 10) 
  {
		results = false;
	}
	return results;
}

//function
void calcScore(double& judgeScore1, double& judgeScore2, double& judgeScore3, double& judgeScore4, double& judgeScore5) 
{
	double average;
	double highestScore = findHighest(judgeScore1, judgeScore2, judgeScore3, judgeScore4, judgeScore5);
	double lowestScore = findLowest(judgeScore1, judgeScore2, judgeScore3, judgeScore4, judgeScore5);
	average = ((judgeScore1 + judgeScore2 + judgeScore3 + judgeScore4 + judgeScore5 - highestScore - lowestScore) / 3);
	cout << setprecision(2) << fixed;
	cout << " Your average score amogst the judges is: " << average << endl;
}

// function
double findHighest(double& judgeScore1, double& judgeScore2, double& judgeScore3, double& judgeScore4, double& judgeScore5) {
	double highestScore = judgeScore1;
	if (highestScore < judgeScore2)
		highestScore = judgeScore2;
	if (highestScore < judgeScore3)
		highestScore = judgeScore3;
	if (highestScore < judgeScore4)
		highestScore = judgeScore4;
	if (highestScore < judgeScore5)
		highestScore = judgeScore5;


	return highestScore;
}

//functions
double findLowest(double& judgeScore1, double& judgeScore2, double& judgeScore3, double& judgeScore4, double& judgeScore5) {
	double lowestScore = judgeScore1;
	if (lowestScore > judgeScore2)
		lowestScore = judgeScore2;
	if (lowestScore > judgeScore3)
		lowestScore = judgeScore3;
	if (lowestScore > judgeScore4)
		lowestScore = judgeScore4;
	if (lowestScore > judgeScore5)
		lowestScore = judgeScore5;

	return lowestScore;
}
