/* Sangram Mathews
CSC 111 (1900)
Prof. Yakov Genis
Extra Project 6
Overloaded Hospital
*/
#include <iostream>
#include <iomanip>
using namespace std;

int charge(int stayDay,int dailyRate,int service,int medication)		//inpatient's total charges
{
	int totalCharges;
	totalCharges=stayDay*dailyRate+service+medication;
	return totalCharges;
}

int charge(int service,int medication)							//outpatient's total charges
{
	int totalCharges;
	totalCharges=service+medication;
	return totalCharges;
}

int validate(int input)											//check whether the input is less than 0 or not
{
	while(input<=0 || input=='\0')								//If it is less than 0 ,input again.
	{
		cout<<"Error. Please input again: ";
		cin>>input;
	}
	return input;
}

int inpatient()
{
	int stayDay,dailyRate,service,medication,totalCharges;
	cout<<"The number of days spent in the hospital: ";
	cin>>stayDay;
	cout<<endl;
	stayDay=validate(stayDay);								//call validate func to check  whether stayDay is less than 0 or not
			
	cout<<"The daily rate: ";
	cin>>dailyRate;
	cout<<endl;
	dailyRate=validate(dailyRate);							//call validate func to check  whether dailyRate is less than 0 or not
			
	cout<<"Charges for hospital services: ";				//call validate func to check  whether service is less than 0 or not
	cin>>service;
	cout<<endl;
	service=validate(service);
		
	cout<<"Hospital medication charges: ";					//call validate func to check  whether medication is less than 0 or not
	cin>>medication;
	cout<<endl;
	medication=validate(medication);		
		
	totalCharges=charge(stayDay,dailyRate,service,medication);			//call overloaded func charge(int,int,int,int)
	return totalCharges;		
}

int outpatient()
{
	int service,medication,totalCharges;
	cout<<"Charges for hospital services: ";				//call validate func to check  whether service is less than 0 or not
	cin>>service;
	cout<<endl;
	service=validate(service);

	cout<<"Hospital medication charges: ";					//call validate func to check  whether medication is less than 0 or not
	cin>>medication;
	cout<<endl;
	medication=validate(medication);
		
	totalCharges=charge(service,medication);				//call overloaded func charge(int,int)
	return totalCharges;
}
int main()
{
	int patient,totalCharges;
	do{																//avoid to input wrong number of patient
		cout<<"Choose one: (1)Inpatient (2)Outpatient  (Please choose one option) : ";
		cin>>patient;
		cout<<endl;
	
		if(patient==1)												//Inpatient
			totalCharges=inpatient();
		else if(patient==2)											//Outpatient
			totalCharges=outpatient();
	}while(patient!=1 && patient !=2);
	
	cout<<"Total charges: "<<totalCharges;
	
	cin.get();
	return 0;
}