// Sangram Mathews
// CSC 111 (1900)
// Prof. Yakov

#include <iostream>
using namespace std;

int main()
{
    const int surveyed = 16500;
    float percentage_per_week = .15,
        percentage_citrus = .58,
        total_per_week = surveyed * percentage_per_week;
      int total_citrus = total_per_week * percentage_citrus;

    cout << "The number of customers who bought 1 or more energy drinks per week is: " << total_per_week << endl;
    cout << "The number of customers who prefer citrus flavor is: " << total_citrus << endl;

    return 0;
}