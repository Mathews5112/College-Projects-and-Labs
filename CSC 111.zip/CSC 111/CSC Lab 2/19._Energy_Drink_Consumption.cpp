#include <iostream>
using namespace std;

int main()
{
    const int surveyed = 16500;
    float percent_1_week = .15,
        citrus = .58,
        total_1_week = surveyed * percent_1_week,
        citrus_total = total_1_week * citrus;

    cout << endl << endl;
    cout << "The number of customers who bought 1 or more neergy drinks a week is: ";
    cout << total_1_week << endl;
    cout << "The number of customers who prefer citrus flavor is: ";
    cout << citrus_total << endl;
    cout << endl << endl;

    return 0;
}