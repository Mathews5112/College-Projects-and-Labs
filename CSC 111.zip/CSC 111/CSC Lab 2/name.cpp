// This program will write the name, address and telephone
// number of the programmer.

// Sangram Mathews
// CSC 111 (1900)
// Prof. Yakov
#include <iostream>
using namespace std;

int main()
{
	cout << "Hello, my name is Sangram Mathews" << endl;
	cout << "I live in 8907 89th ave, jamaica" << endl;
	cout << "It is located on New York" << endl;
	cout << "My phone number is 6467644467" << endl;

	return 0;
}