#include<iostream>

using namespace std;
//prototype
void Swap(int &, int &);

int main()
{
	int number1, number2;

	cout << "Please enter 2 numbers: ";
	cin >> number1 >> number2;
	cout << "Before swapping,\n the values are "
		<< number1 << " and " << number2 << endl;
	//function call
	Swap(number1, number2);

	cout << "After swapping,\n the values are "
		<< number1 << " and " << number2 << endl;

	return 0;
}

//definition
void Swap(int &n1, int& n2)
{
	int n3;
	cout << "In the function, Before swapping,\n the values are "
		<< n1 << " and " << n2 << endl;

	n3 = n1;
	n1 = n2;
	n2 = n3;
	cout << "In the function,After swapping,\n the values are "
		<< n1 << " and " << n2 << endl;
}