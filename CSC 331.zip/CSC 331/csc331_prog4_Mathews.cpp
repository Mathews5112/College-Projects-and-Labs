/* Name: Sangram Mathews
   Semester: Fall 2021
   CSC 331-172B
   Professor K Byron
   Due Date: 11/29/2021
   Programming assignment 4

Purpose of this program is to use an array-based heap to implement a priority queue and perform repair service in
the ascending order of dates.
Users have to enter data in this format: name-year-y or n
[If high priority then enter y and for least priority enter n]
Enter 'service' to repair
Enter 'end-of-file' to see how many repairings left */ 



#include <iostream>
#include<string>
#include <cstdio>
#include <cstring>
#include <cstdlib>
using namespace std;

// Declaring Node for the queue
struct node
{
int priority;
string info;
struct node *next;
};
// Implementing Priority Queue
class Priority_Queue
{
   private:
   node *f;
  
   public:
   Priority_Queue()
   {
   f = NULL;
   }
   void insert(string i, int p) // Function that inserts data into Queue
   {
   node *t, *q;
   t = new node;
   t->info = i;
   t->priority = p;
   if (f == NULL || p < f->priority)
   {
   t->next = f;
   f = t;
   }
   else
   {
   q = f;
   while (q->next != NULL && q->next->priority <= p)
   q = q->next;
   t->next = q->next;
   q->next = t;
   }
   }
   void delet()
   {
   node *t;
   if (f == NULL) //if queue is null
   cout << "Queue Underflow\n";
   else
   {
   t = f;
   cout << "Item Repaired : "<< t->info << endl;
   f = f->next;
   free(t);
   }
   }
   void show() //print queue {
   {
   node *ptr;
   ptr = f;
   if (f == NULL)
   cout << "Queue is empty\n";
   else
   {
       int cnt = 0;
   while (ptr != NULL)
   {
       cnt++;
   ptr = ptr->next;
   }
   cout<<"There are "<<cnt<<" Repair orders in queue"<<endl;
   }
}
};
int main()
{
int p;
string c;
string i;
Priority_Queue pq;
do
{
cout << "Enter data : ";
cin >> c;
int x = c.compare("end-of-file");
if ( x != 0) {
   if (c == "service") {
       pq.delet();
       } else {
       int i = c.find('-');
       string name = c.substr(0, i);
           string temp = c.substr(i+1, c.length());
           i = temp.find('-');
           string year = temp.substr(0,i);
           char year_char[year.size() + 1];
            strcpy(year_char, year.c_str());
            int year_int = atoi(year_char);
           string warranty = temp.substr(i+1, temp.length());
           int priority;
           if (warranty == "y") {
               priority = 1;
           } else if ( 2020 - year_int < 6) {
               priority = 2;
           } else {
               priority = 3;
           }
           pq.insert(name, priority);
       }
   }
   else{
       break;
   }

} while (c != "end-of-file");
pq.show();
return 0;
}