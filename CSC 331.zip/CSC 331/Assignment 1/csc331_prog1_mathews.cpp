// Sangram Mathews
// CSC 331-172B
// csc331_prog1_mathews.cpp
// Assignment 1
// Due date: 9/13/2021
// Purpose of this program is to
// print a message and
// capture the output in a txt file

#include<iostream>
#include<fstream>

using namespace std;

//main method
int main()
{
//declaring a string variable
string message;
//string variable to handle the output file
ofstream myfile;

//string variable that stores the message
message = "Hello World";

//printing the message in the console
cout<< message << endl;

//opening the file with the given name
myfile.open("csc331_prog1_mathews.txt");
//redirecting the message to the output txt file
myfile<< message;
//closing the file
myfile.close();

return 0;
}