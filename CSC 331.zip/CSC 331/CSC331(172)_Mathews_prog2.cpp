//Name: Sangram Mathews
//CSC 331-172B
//Prof. Kevin Byron
//Assignment Program #2

#include<bits/stdc++.h>
using namespace std;

class Node {
   public:
   int age;
   string name;
   Node * next;
};

void add(Node** head_ref, string name, int age)   
{   
  
// 1. allocate node
Node* new_node = new Node();
  
// Used in step 5
Node *last = *head_ref;
  
// 2. Put in the data
new_node->age = age;
       new_node->name = name;
  
// 3. This new node is going to be   
// the last node, so make next of   
// it as NULL
new_node->next = NULL;   
  
// 4. If the Linked List is empty,
// then make the new node as head
if (*head_ref == NULL)   
{   
*head_ref = new_node;
cout<<"name added"<<endl;
return;   
}   
  
// 5. Else traverse till the last node
while (last->next != NULL)
   {
       string s1=new_node->name;
       string s2=last->name;
       transform(s1.begin(), s1.end(), s1.begin(), ::tolower);
       transform(s2.begin(), s2.end(), s2.begin(), ::tolower);
       if(s1.compare(s2)==0)
       {
           cout<<"name not added"<<endl;
           return;
       }
last = last->next;   
   }
// 6. Change the next of last node
last->next = new_node;   
   cout<<"name added"<<endl;
return;   
}   

void deleteNode(Node **head_ref, string name)
{
// Store head node
Node* temp = *head_ref, *prev;
   string s=temp->name;
   transform(s.begin(), s.end(), s.begin(), ::tolower);
   transform(name.begin(), name.end(), name.begin(), ::tolower);
          
// If head node itself holds the key to be deleted
if (temp != NULL && !s.compare(name))
{
*head_ref = temp->next; // Changed head
free(temp); // free old head
return;
}
  
// Search for the key to be deleted, keep track of the
// previous node as we need to change 'prev->next'
while (temp != NULL && s.compare(name))
{
prev = temp;
temp = temp->next;
       s=temp->name;
       transform(s.begin(), s.end(), s.begin(), ::tolower);
}
  
// If key was not present in linked list
if (temp == NULL)
   {
       cout<<"name not found"<<endl;
       return;}
  
// Unlink the node from linked list
prev->next = temp->next;
   cout<<"name deleted"<<endl;
free(temp); // Free memory
}

void printList( Node **head_ref)
{
   Node *node = *head_ref;
while (node != NULL)
{
cout<<node->name<<" "<<node->age<<endl;;
node = node->next;
}
}


int main()
{
   Node * head=NULL;
   while(1)
   {
       string str;
       cout<<"Enter transaction: ";
       getline(cin,str);
       if(str[0]=='Q')
           break;
       else if(str[0]=='A')
       {
           string name,age;
           int k=2;
           while(str[k]!=' ')
           {
               name+=str[k];
               k++;
           }
           k++;
           while(str[k]!='\0')
           {
               age+=str[k];
               k++;
           }
           int num=stoi(age);
           add(&head,name,num);
       }
       else if(str[0]=='D')
       {
           string name="";
           int k=2;
           while(str[k]!='\0')
           {
               name+=str[k];
               k++;
           }
           deleteNode(&head,name);
       }
       else if(str[0]=='L')
       {
           printList(&head);
       }
       else
       {
           cout<<"Wrong transaction"<<endl;
       }
   }
}