/* Name: Sangram Mathews
Semester: Fall 2021
CSC 331 (172)
Programming Assignment 5
Due Date: 12/13/21
Purpose: This program identifies a minimum spanning tree (MST) in an undirected connected weighted graph.
Type end-of-file to terminate and get results. 
*/

#include <bits/stdc++.h>

using namespace std;
class Edge
{
public:
int src, dest, weight;
};
// class to represent a connected, undirected and weighted graph
class Graph
{
public:
// Vn = Number of vertices, En = Number of edges
int Vn, En;
// graph is represented as an array of edges.
Edge* edge;
};

// function to create a graph with Vn vertices and En edges
Graph* createGraph(int G)
{
Graph* graph = new Graph;
graph->Vn = 100;
graph->En = G;
// array of 100 elements as specified
graph->edge = new Edge[100];
return graph;
}
class subset
{
public:
int parent;
int rank;
};

// recursive function to find set of an element x
int find(subset subsets[], int x)
{
if (subsets[x].parent != x)
subsets[x].parent = find(subsets, subsets[x].parent);
return subsets[x].parent;
}

void Union(subset subsets[], int a, int b)
{
int xroot = find(subsets, a);
int yroot = find(subsets, b);
// rank tree 
if (subsets[xroot].rank < subsets[yroot].rank)
subsets[xroot].parent = yroot;
else if (subsets[xroot].rank > subsets[yroot].rank)
subsets[yroot].parent = xroot;
else
{
subsets[yroot].parent = xroot;
subsets[xroot].rank++;
}
}

// using this on qsort() for sorting an array of edges
int myComp(const void* a, const void* b)
{
Edge* a1 = (Edge*)a;
Edge* b1 = (Edge*)b;
return a1->weight > b1->weight;
}
// required function
void KruskalMST(Graph* graph)
{
int V = graph->Vn;
Edge result[V]; // This will store the resultant MST
int e = 0;
int i = 0; // An index variable, used for sorted edges
qsort(graph->edge, graph->En, sizeof(graph->edge[0]), myComp);
subset *subsets = new subset[( V * sizeof(subset) )];

// Create P subsets with single elements
for (int p = 0; p < V; ++p)
{
subsets[p].parent = p;
subsets[p].rank = 0;
}
while (e < V - 1 && i < graph->En)
{
Edge next_edge = graph->edge[i++];
int x = find(subsets, next_edge.src);
int y = find(subsets, next_edge.dest);
if (x != y)
{
result[e++] = next_edge;
Union(subsets, x, y);
}
// Else discard the next_edge
}
// print the contents of result[]
// for total cost
int cost = 0;
cout<<"\nMinimum spanning tree:\n";
for (i = 0; i < e; ++i)
{
cout<<result[i].src<<" "<<result[i].dest<<" "<<result[i].weight<<endl;
cost+= result[i].weight;
}
cout << "Edge weight total: " << cost << endl;
return;
}
// Driver code
int main()
{
cout<< "\nPlease enter 3 non-negative integers from 0-99 \nseparated by a space\n";
// now take input transactions
string line;
// store all lines in a vector
vector<string> inputs;
int E = 0; // Number of edges in graph
while(true)
{
getline(cin, line);
// to terminate the program 
if(line == "end-of-file")
break;
inputs.push_back(line);
// increase number of edges
E++;
}
Graph* graph = createGraph(E);
for(int i=0; i<E; i++)
{
line = inputs[i];
string word = "";
int flag = 0;
for(int t=0; line[t]!='\0'; t++)
{
if(line[t]==' ')
{
if(flag == 0) // src
{
graph->edge[i].src = stoi(word);
flag = 1;
}
else // dest
{
graph->edge[i].dest = stoi(word);
}
word = "";
}
else // add the characters to word
{
word = word + line[t];
}
}
graph->edge[i].weight = stoi(word); //string to integer
}
KruskalMST(graph);
return 0;
}