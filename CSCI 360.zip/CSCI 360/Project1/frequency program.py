# Function to calculate the frequency of letters in a given text
def calculate_letter_frequency(text):
    # Initialize a dictionary to hold the frequency of each letter
    frequency = {chr(i): 0 for i in range(ord('A'), ord('Z')+1)}
    
    # Convert the text to uppercase to handle both cases
    text = text.upper()
    
    # Count the frequency of each letter in the text
    for char in text:
        if char in frequency:
            frequency[char] += 1
    
    # Calculate the total number of letters in the text
    total_letters = sum(frequency.values())
    
    # Calculate the relative frequency of each letter
    relative_frequency = {char: (count / total_letters) * 100 for char, count in frequency.items()}
    
    return relative_frequency

# Ciphertext provided in the problem
ciphertext = "lrvmnir bpr sumvbwvr jx bpr lmiwv yjeryrkbi jx qmbm wi bpr xjvni mkd ymibrut jx irhx wi bpr riirkvr jx ymbinlmtmipw utn qmumbr dj w ipmhh but bj rhnvwdmbr bpr yjeryrkbi jx bpr qmbm mvvjudwko bj yt wkbrusurbmbwjk lmird jk xjubt trmui jx ibndt wb wi kjb mk rmit bmiq bj rashmwk rmvp yjeryrkb mkd wbi iwokwxwvmkvr mkd ijyr ynib urymwk nkrashmwkrd bj ower m vjyshrbr rashmkmbwjk jkr cjnhd pmer bj lr fnmhwxwrd mkd wkiswurd bj invp mk rabrkb bpmb pr vjnhd urmvp bpr ibmbr jx rkhwopbrkrd ywkd vmsmlhr jx urvjokwgwko ijnkdhrii ijnkd mkd ipmsrhrii ipmsr w dj kjb drry ytirhx bpr xwkmh mnbpjuwbt lnb yt rasruwrkvr cwbp qmbm pmi hrxb kj djnlb bpmb bpr xjhhjcwko wi bpr sujsru msshwvmbwjk mkd wkbrusurbmbwjk w jxxru yt bprjuwri wk bpr pjsr bpmb bpr riirkvr jx jqwkmcmk qmumbr cwhh urymwk wkbmvb"
# Calculate and print the letter frequencies
frequency = calculate_letter_frequency(ciphertext)
for letter, freq in frequency.items():
    print(f"{letter}: {freq:.2f}%")
