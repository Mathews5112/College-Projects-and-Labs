import random
from MRT import generate_prime
from EA import gcd
from EEA import modular_inverse
def rsa_key_generation(s):
    # Step 1: Generate two distinct primes p and q of s bits
    while True:
        p = generate_prime(s)
        q = generate_prime(s)
        if p != q:
            break

    # Step 2: Compute n = p * q
    n = p * q

    # Step 3: Compute φ(n) = (p - 1) * (q - 1)
    phi_n = (p - 1) * (q - 1)

    # Step 4: Choose e such that 1 < e < φ(n) and gcd(e, φ(n)) == 1
    while True:
        e = random.randint(2, phi_n - 1)
        if gcd(e, phi_n) == 1:
            break

    # Step 5: Compute d = e^-1 mod φ(n)
    d = modular_inverse(e, phi_n)

    # Ensure d is at least 0.3 * s bits long
    while d is None or d.bit_length() < int(0.3 * s):
        e = random.randint(2, phi_n - 1)
        if gcd(e, phi_n) == 1:
            d = modular_inverse(e, phi_n)

    # Step 6: Output public and private keys
    kpub = (n, e)
    kpr = d
    return kpub, kpr

# Example usage
if __name__ == "__main__":
    s = 512  # You can change the bit size as needed
    kpub, kpr = rsa_key_generation(s)
    print(f"Public Key (n, e): {kpub}")
    print(f"Private Key d: {kpr}")
