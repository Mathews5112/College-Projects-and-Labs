from powmod_sm import powmod_sm

def rsa_decrypt(kpr, kpub, y):
    d = kpr
    n, _ = kpub  # Extract modulus n from public key

    # Decrypt: x = y^d mod n
    x = powmod_sm(y, d, n)

    return x

# Example usage
if __name__ == "__main__":
    # Generate keypair
    from RSA_keygen import rsa_key_generation  # replace with your actual keygen file name
    kpub, kpr = rsa_key_generation(512)  # 512 bits for example

    # Encrypt
    from RSA_encrypt import rsa_encrypt  # replace with your actual encrypt file name
    x_original, y = rsa_encrypt(kpub)
    print(f"Original plaintext x: {x_original}")
    print(f"Ciphertext y: {y}")

    # Decrypt
    x_decrypted = rsa_decrypt(kpr, kpub, y)
    print(f"Decrypted plaintext x: {x_decrypted}")

    # Verification
    if x_original == x_decrypted:
        print("Success: Decryption matches the original plaintext.")
    else:
        print("Error: Decryption does not match the original plaintext.")
