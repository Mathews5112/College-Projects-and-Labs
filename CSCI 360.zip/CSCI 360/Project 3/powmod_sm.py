def powmod_sm(base, exponent, modulus):
    """
    Perform modular exponentiation using the Square and Multiply algorithm.

    Parameters:
    base (int): The base number
    exponent (int): The exponent
    modulus (int): The modulus

    """
    if modulus == 0:
        raise ValueError("Modulus cannot be zero.")

    result = 1
    base = base % modulus  # Ensure base is within the range of modulus

    while exponent > 0:
        # If the current exponent bit is 1, multiply the result by the base
        if exponent % 2 == 1:
            result = (result * base) % modulus

        # Square the base and reduce it modulo the modulus
        base = (base * base) % modulus
        exponent //= 2  # Shift the exponent to the right (divide by 2)

    return result  # Return the final result

# Example usage
if __name__ == "__main__":
    try:
        base = int(input("Enter the base: "))
        exponent = int(input("Enter the exponent: "))
        modulus = int(input("Enter the modulus: "))
        print(f"The result of ({base}^{exponent}) % {modulus} is {powmod_sm(base, exponent, modulus)}")
    except ValueError as e:
        print(e)