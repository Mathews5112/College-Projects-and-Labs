def gcd(a, b):
    """
    Calculate the Greatest Common Divisor (GCD) of two numbers using the Euclidean Algorithm.

    Parameters:
    a (int): First number
    b (int): Second number

    Returns:
    int: GCD of a and b
    """
    while b != 0:
        a, b = b, a % b
    return a

# Example usage
if __name__ == "__main__":
    num1 = int(input("Enter the first number: "))
    num2 = int(input("Enter the second number: "))
    print(f"The GCD of {num1} and {num2} is {gcd(num1, num2)}")