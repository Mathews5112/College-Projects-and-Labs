def modular_inverse(a, m):
    """
    Extended Euclidean Algorithm to find the modular inverse of a modulo m.
    
    Parameters:
    a (int): The number to invert.
    m (int): The modulus.
    
    Returns:
    int: The modular inverse of a modulo m, or None if it doesn't exist.
    """
    if m == 0:
        raise ValueError("Modulo cannot be zero.")

    m0 = m
    x0, x1 = 0, 1

    while a > 1:
        q = a // m
        a, m = m, a % m
        x0, x1 = x1 - q * x0, x0

    # If GCD is not 1, inverse doesn't exist
    if a != 1:
        return None

    return x1 + m0 if x1 < 0 else x1

# Example usage
if __name__ == "__main__":
    a = int(input("Enter a: "))
    m = int(input("Enter modulus m: "))
    inv = modular_inverse(a, m)
    if inv is None:
        print(f"No modular inverse exists for {a} mod {m}")
    else:
        print(f"Modular inverse of {a} mod {m} is {inv}")
