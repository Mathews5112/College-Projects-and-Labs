#!/usr/bin/perl
#Using strict and warnings for better error checking
use strict;
use warnings;
#Code to open the text file in read mode
my $file = 'electricity.txt';
open(my $fh, '<', $file) or die "Cannot open $file: $!";

# Read and normalize words
my %word_count;
while (<$fh>) {
    chomp;
    s/[^a-zA-Z0-9\s]//g;        # Remove punctuation
    my @words = split(/\s+/, lc($_)); # Lowercase and split
    $word_count{$_}++ for @words;
}
close($fh);

# Output: alphabetically
print "== Words Sorted Alphabetically ==\n";
foreach my $word (sort { lc($a) cmp lc($b) } keys %word_count) {
    printf "%-15s %5d\n", $word, $word_count{$word};
}

# Output: by frequency, alphabetically within same frequency
print "\n== Words Sorted by Frequency ==\n";
foreach my $word (
    sort {
        $word_count{$b} <=> $word_count{$a} ||
        lc($a) cmp lc($b)
    } keys %word_count
) {
    printf "%-15s %5d\n", $word, $word_count{$word};
}
