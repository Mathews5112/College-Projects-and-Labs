#!/usr/bin/perl
# using strict and warnings for better error checking
use strict;
use warnings;

# Read the solar.txt file
my $filename = 'solar.txt';
open(my $fh, '<', $filename) or die "Cannot open $filename: $!";

#Part 1.1
print "== 1. Records without a discoverer (Field 8 missing): ==\n";
seek($fh, 0, 0);  # Reset file pointer
#while loop for searching the field 8 missing records
while (my $line = <$fh>) {
    chomp $line;
    my @fields = split(/\s+/, $line, 9);
    print "$line\n" if ($fields[7] eq '-' or $fields[7] eq '');
}
#Part 1.2
seek($fh, 0, 0);
print "\n== 2. Records with the 8th field (discoverer) omitted: ==\n";
#While loop to search for the records and omitt 8th field
while (my $line = <$fh>) {
    chomp $line;
    my @fields = split(/\s+/, $line, 9);
    $fields[7] = '';  # Remove discoverer
    print join(' ', grep { $_ ne '' } @fields), "\n";
}
#Part 1.3
seek($fh, 0, 0);
print "\n== 3. Records discovered by Jewitt: ==\n";
#While loop to search for records with Jewitt
while (my $line = <$fh>) {
    chomp $line;
    my @fields = split(/\s+/, $line, 9);
    print "$line\n" if ($fields[7] eq 'Jewitt');
}
#Part 1.4
seek($fh, 0, 0);
print "\n== 4. Records with orbital period converted to seconds: ==\n";
#While loop to search for records and convert orbital period in seconds instead of days
while (my $line = <$fh>) {
    chomp $line;
    my @fields = split(/\s+/, $line, 9);
    if ($fields[4] =~ /^-?\d*\.?\d+$/) {
        my $period_sec = $fields[4] * 86400;
        $fields[4] = sprintf("%.2f", $period_sec);
    }
    print join(' ', @fields), "\n";
}

close($fh);