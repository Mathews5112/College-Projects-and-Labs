#!/usr/bin/perl
#Using strict and warnings for better error handling
use strict;
use warnings;

#Input the digit
print "Enter a number: ";
my $input = <STDIN>; #declare local variable
chomp($input); #remove newline

if (is_valid_integer($input)) { #if statement
    print "True: '$input' is a valid Perl integer.\n";
} else {
    print "False: '$input' is NOT a valid Perl integer.\n";
}

sub is_valid_integer { #valid integer function
    my ($val) = @_; #predefined list variable to contain all parameters

    return 1 if ($val =~ /^-?[1-9][0-9]*$|^0$/);               # Decimal
    return 1 if ($val =~ /^0[0-7]+$/);                         # Octal
    return 1 if ($val =~ /^0[xX][0-9a-fA-F]+$/);               # Hexadecimal

    return 0;
}
