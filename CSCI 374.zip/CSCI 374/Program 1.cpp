#include <iostream>
#include <chrono>

const int SIZE = 10000; // Large array
const int CALLS = 100000;

void staticArray() {
    static int arr[SIZE];
    for (int i = 0; i < SIZE; ++i) {
        arr[i] = i;
    }
}

void stackArray() {
    int arr[SIZE];
    for (int i = 0; i < SIZE; ++i) {
        arr[i] = i;
    }
}

void heapArray() {
    int* arr = new int[SIZE];
    for (int i = 0; i < SIZE; ++i) {
        arr[i] = i;
    }
    delete[] arr;
}

int main() {
    using namespace std::chrono;

    auto start = high_resolution_clock::now();
    for (int i = 0; i < CALLS; ++i)
        staticArray();
    auto end = high_resolution_clock::now();
    std::cout << "Static array time: "
              << duration_cast<milliseconds>(end - start).count() << " ms\n";

    start = high_resolution_clock::now();
    for (int i = 0; i < CALLS; ++i)
        stackArray();
    end = high_resolution_clock::now();
    std::cout << "Stack array time: "
              << duration_cast<milliseconds>(end - start).count() << " ms\n";

    start = high_resolution_clock::now();
    for (int i = 0; i < CALLS; ++i)
        heapArray();
    end = high_resolution_clock::now();
    std::cout << "Heap array time: "
              << duration_cast<milliseconds>(end - start).count() << " ms\n";

    return 0;
}
