#include <iostream>
#include <chrono>

const int ROWS = 500;
const int COLS = 500;
const int ITER = 1000;

// Subscript-based function
void subscriptAccess() {
    int arr[ROWS][COLS] = {{0}};
    for (int k = 0; k < ITER; ++k)
        for (int i = 0; i < ROWS; ++i)
            for (int j = 0; j < COLS; ++j)
                arr[i][j]++;
}

// Pointer arithmetic-based function
void pointerAccess() {
    int arr[ROWS][COLS] = {{0}};
    for (int k = 0; k < ITER; ++k)
        for (int i = 0; i < ROWS; ++i)
            for (int j = 0; j < COLS; ++j)
                *(*(arr + i) + j) += 1;
}

int main() {
    using namespace std::chrono;

    auto start = high_resolution_clock::now();
    subscriptAccess();
    auto end = high_resolution_clock::now();
    std::cout << "Subscript access time: "
              << duration_cast<milliseconds>(end - start).count() << " ms\n";

    start = high_resolution_clock::now();
    pointerAccess();
    end = high_resolution_clock::now();
    std::cout << "Pointer access time: "
              << duration_cast<milliseconds>(end - start).count() << " ms\n";

    return 0;
}
