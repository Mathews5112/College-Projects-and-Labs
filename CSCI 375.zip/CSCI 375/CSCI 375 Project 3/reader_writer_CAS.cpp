#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// =========================
//   Compare-and-Swap primitive (simulated)
// =========================

bool compareAndSwap(int &target, int expected, int newValue) {
    if (target == expected) {
        target = newValue;
        return true;
    }
    return false;
}

// =========================
//   Global Constants
// =========================

const int N_READERS        = 3;
const int N_WRITERS        = 3;
const int MAX_READER_ITERS = 3;
const int MAX_WRITER_ITERS = 3;
const int MAX_STEPS        = 400;

// =========================
//   Shared State (CAS-managed)
// =========================
// rwState >= 0 : number of readers inside (0,1,2)
// rwState == -1: one writer inside, no readers
int rwState = 0;

// For debug / panic checks (not used for control)
int activeReaders = 0;
int activeWriters = 0;

// Single-slot shared buffer
int sharedBuffer = 0;

void panic(const string &msg) {
    cout << "***** PANIC: " << msg << " *****" << endl;
}

// =========================
//   CAS-based Entry / Exit Helpers
// =========================

// Try to acquire a reader slot using CAS
bool try_enter_reader() {
    int old = rwState;
    // writer present or limit (2 readers) reached
    if (old == -1 || old >= 2) return false;
    return compareAndSwap(rwState, old, old + 1);
}

// Try to acquire the writer slot using CAS
bool try_enter_writer() {
    int old = rwState;
    if (old != 0) return false;   // someone is inside
    return compareAndSwap(rwState, 0, -1);
}

// Try to exit as reader (decrement reader count)
bool try_exit_reader() {
    int old = rwState;
    if (old <= 0) {
        panic("try_exit_reader sees invalid State");
        return true; // treat as progress to avoid spinning forever
    }
    int newVal = old - 1;
    return compareAndSwap(rwState, old, newVal);
}

// Try to exit as writer (set from -1 to 0)
bool try_exit_writer() {
    int old = rwState;
    if (old != -1) {
        panic("try_exit_writer sees invalid State");
        return true;
    }
    return compareAndSwap(rwState, -1, 0);
}

// =========================
//   Per-process State
// =========================

int r_pc[N_READERS];      // reader program counters
int w_pc[N_WRITERS];      // writer program counters
int r_iters[N_READERS];   // completed CS iterations (readers)
int w_iters[N_WRITERS];   // completed CS iterations (writers)
int readerBusy[N_READERS];
int writerBusy[N_WRITERS];

// =========================
//   Reader Process Step
// =========================

bool step_reader(int id) {
    bool event = false;
    if (r_pc[id] == -1) return false;  // already finished

    switch (r_pc[id]) {
        case 0: // try to acquire reader slot using CAS
            if (try_enter_reader()) {
                cout << "Reader " << id
                     << " acquired reader slot via CAS (rwState="
                     << rwState << ")\n";
                r_pc[id] = 1;
                event = true;
            }
            break;

        case 1: // ENTER CS bookkeeping
            activeReaders++;
            cout << "Reader " << id << " ENTER CS. "
                 << "activeReaders=" << activeReaders
                 << ", activeWriters=" << activeWriters << "\n";
            cout << "Reader " << id << ": other readers inside = "
                 << (activeReaders - 1)
                 << ", writers inside = " << activeWriters << "\n";

            if (activeWriters > 0) panic("Reader in CS while writer present");
            if (activeReaders > 2) panic("More than 2 readers in CS");

            // stay in CS for several scheduler cycles
            readerBusy[id] = 5;
            r_pc[id] = 2;
            event = true;
            break;

        case 2: // busy loop inside CS, then read
            if (readerBusy[id] > 0) {
                cout << "Reader " << id << " busy-loop inside CS ("
                     << readerBusy[id] << " cycles left)\n";
                if (activeWriters > 0) panic("Reader in CS while writer present");
                if (activeReaders > 2) panic("More than 2 readers in CS");
                readerBusy[id]--;
                event = true;
                break;
            }
            // perform the actual read
            cout << "Reader " << id << " is READING...\n";
            cout << "Reader " << id
                 << " reads value " << sharedBuffer
                 << " from sharedBuffer\n";
            if (activeWriters > 0) panic("Reader in CS while writer present");
            if (activeReaders > 2) panic("More than 2 readers in CS");
            r_pc[id] = 3;
            event = true;
            break;

        case 3: // try to exit: CAS decrement rwState
            if (try_exit_reader()) {
                activeReaders--;
                cout << "Reader " << id << " EXIT CS. activeReaders="
                     << activeReaders << ", rwState=" << rwState << "\n";
                r_iters[id]++;
                if (r_iters[id] >= MAX_READER_ITERS) {
                    cout << "Reader " << id << " DONE all iterations\n";
                    r_pc[id] = -1;
                } else {
                    r_pc[id] = 0;
                }
                event = true;
            }
            break;

        default:
            break;
    }

    return event;
}

// =========================
//   Writer Process Step
// =========================

bool step_writer(int id) {
    bool event = false;
    if (w_pc[id] == -1) return false;  // already finished

    switch (w_pc[id]) {
        case 0: // try to acquire writer slot using CAS
            if (try_enter_writer()) {
                cout << "Writer " << id
                     << " acquired writer slot via CAS (rwState="
                     << rwState << ")\n";
                w_pc[id] = 1;
                event = true;
            }
            break;

        case 1: // ENTER CS bookkeeping
            activeWriters++;
            cout << "Writer " << id << " ENTER CS. "
                 << "activeReaders=" << activeReaders
                 << ", activeWriters=" << activeWriters << "\n";
            cout << "Writer " << id << ": other readers inside = "
                 << activeReaders
                 << ", other writers inside = " << (activeWriters - 1) << "\n";

            if (activeReaders > 0) panic("Writer in CS while readers present");
            if (activeWriters > 1) panic("More than one writer in CS");

            // stay in CS for several scheduler cycles
            writerBusy[id] = 4;
            w_pc[id] = 2;
            event = true;
            break;

        case 2: // busy loop inside CS, then write
            if (writerBusy[id] > 0) {
                cout << "Writer " << id << " busy-loop inside CS ("
                     << writerBusy[id] << " cycles left)\n";
                if (activeReaders > 0) panic("Writer in CS while readers present");
                if (activeWriters > 1) panic("More than one writer in CS");
                writerBusy[id]--;
                event = true;
                break;
            }
            // perform the actual write
            cout << "Writer " << id << " is WRITING...\n";
            {
                int value = (id + 1) * 100 + (w_iters[id] + 1);
                sharedBuffer = value;
                cout << "Writer " << id
                     << " writes value " << sharedBuffer
                     << " to sharedBuffer\n";
            }
            if (activeReaders > 0) panic("Writer in CS while readers present");
            if (activeWriters > 1) panic("More than one writer in CS");
            w_pc[id] = 3;
            event = true;
            break;

        case 3: // try to exit: CAS set rwState from -1 to 0
            if (try_exit_writer()) {
                activeWriters--;
                cout << "Writer " << id << " EXIT CS. activeWriters="
                     << activeWriters << ", rwState=" << rwState << "\n";
                w_iters[id]++;
                if (w_iters[id] >= MAX_WRITER_ITERS) {
                    cout << "Writer " << id << " DONE all iterations\n";
                    w_pc[id] = -1;
                } else {
                    w_pc[id] = 0;
                }
                event = true;
            }
            break;

        default:
            break;
    }

    return event;
}

// =========================
//   Scheduler Helpers
// =========================

bool all_finished() {
    for (int i = 0; i < N_READERS; i++)
        if (r_pc[i] != -1) return false;
    for (int i = 0; i < N_WRITERS; i++)
        if (w_pc[i] != -1) return false;
    return true;
}

// =========================
//   Main
// =========================

int main() {
    srand(static_cast<unsigned int>(time(nullptr)));

    for (int i = 0; i < N_READERS; i++) {
        r_pc[i]       = 0;
        r_iters[i]    = 0;
        readerBusy[i] = 0;
    }
    for (int i = 0; i < N_WRITERS; i++) {
        w_pc[i]       = 0;
        w_iters[i]    = 0;
        writerBusy[i] = 0;
    }

    cout << "Starting CAS-based Readers/Writers simulation...\n";

    for (int step = 0; step < MAX_STEPS && !all_finished(); step++) {
        int pid = rand() % (N_READERS + N_WRITERS);
        bool event = false;

        if (pid < N_READERS) {
            int rid = pid;
            event = step_reader(rid);
            if (event) {
                cout << "\n=== Scheduler chose READER " << rid
                     << " at step " << step << " ===\n";
            }
        } else {
            int wid = pid - N_READERS;
            event = step_writer(wid);
            if (event) {
                cout << "\n=== Scheduler chose WRITER " << wid
                     << " at step " << step << " ===\n";
            }
        }
    }

    cout << "\nSimulation finished.\n";
    return 0;
}
