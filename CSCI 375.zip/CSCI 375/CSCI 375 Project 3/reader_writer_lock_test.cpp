#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// =========================
//   "Semaphore" Operations
// =========================

int wait_int(int &s) {
    if (s > 0) {
        s--;
        return 1; // success
    }
    return 0;     // fail, caller must try again later
}

void signal_int(int &s) {
    s++;
}

// =========================
//   Global Constants
// =========================

const int N_READERS = 3;
const int N_WRITERS = 3;
const int MAX_READER_ITERS = 3;
const int MAX_WRITER_ITERS = 3;
const int MAX_STEPS       = 400;

// =========================
//   "Semaphore" Variables
// No OS semaphores used; just ints
// =========================

// binary mutex for readerCount
int mutexSem = 1;

// binary semaphore for writers vs readers
int wrtSem = 1;

// counting semaphore limiting readers in CS to 2
int readSlots = 2;

// =========================
//   Shared State
// =========================

int readerCount   = 0;  // readers in protocol
int activeReaders = 0;  // readers currently in CS
int activeWriters = 0;  // writers currently in CS

// Single-slot shared buffer
int sharedBuffer = 0;   // data written by writers, read by readers

void panic(const string &msg) {
    cout << "***** PANIC: " << msg << " *****" << endl;
}

// =========================
//   Per-process State
// =========================

int r_pc[N_READERS];     // program counters for readers
int w_pc[N_WRITERS];     // program counters for writers
int r_iters[N_READERS];  // number of CS iterations done by readers
int w_iters[N_WRITERS];  // number of CS iterations done by writers

// Busy-loop counters to keep processes longer in CS
int readerBusy[N_READERS];
int writerBusy[N_WRITERS];

// =========================
//   Reader Process Step
//   returns true if an event happened
// =========================

bool step_reader(int id) {
    bool event = false;
    if (r_pc[id] == -1) return false;  // already finished

    switch (r_pc[id]) {
        case 0: // try to get read slot
            if (wait_int(readSlots)) {
                cout << "Reader " << id << " got readSlots\n";
                r_pc[id] = 1;
                event = true;
            }
            break;

        case 1: // wait(mutexSem)
            if (wait_int(mutexSem)) {
                cout << "Reader " << id << " got mutexSem\n";
                r_pc[id] = 2;
                event = true;
            }
            break;

        case 2: // readerCount++
            readerCount++;
            cout << "Reader " << id << " increments readerCount to "
                 << readerCount << "\n";
            if (readerCount == 1) {
                r_pc[id] = 3; // first reader needs wrtSem
            } else {
                r_pc[id] = 4; // skip
            }
            event = true;
            break;

        case 3: // BROKEN: first reader does NOT lock out writers
            if (1) {
            cout << "Reader " << id << " (BROKEN) skips wrtSem wait\n";
                r_pc[id] = 4;
                event = true;
            }
            break;
        case 4: // signal(mutexSem)
            signal_int(mutexSem);
            cout << "Reader " << id << " released mutexSem\n";
            r_pc[id] = 5;
            event = true;
            break;

        case 5: { // ENTER CS
            activeReaders++;
            cout << "Reader " << id << " ENTER CS. "
                 << "activeReaders=" << activeReaders
                 << ", activeWriters=" << activeWriters << "\n";

            cout << "Reader " << id << ": other readers inside = "
                 << (activeReaders - 1)
                 << ", writers inside = " << activeWriters << "\n";

            // Check rules on entry
            if (activeWriters > 0) {
                panic("Reader in CS while writer present");
            }
            if (activeReaders > 2) {
                panic("More than 2 readers in CS");
            }

            // Stay in CS for multiple scheduler cycles:
            readerBusy[id] = 5;  // adjust this number to make CS longer/shorter

            r_pc[id] = 6;        // go to busy-loop state
            event = true;
            break;
        }

        case 6:  // busy loop inside CS, then actual read
            if (readerBusy[id] > 0) {
                cout << "Reader " << id << " busy-loop inside CS ("
                     << readerBusy[id] << " cycles left)\n";

                // Continuous safety checks while inside CS
                if (activeWriters > 0) {
                    panic("Reader in CS while writer present");
                }
                if (activeReaders > 2) {
                    panic("More than 2 readers in CS");
                }

                readerBusy[id]--;   // stay in same case (6)
                event = true;
                break;
            }

            // Busy time over: perform the actual "read"
            cout << "Reader " << id << " is READING...\n";
            cout << "Reader " << id
                 << " reads value " << sharedBuffer
                 << " from sharedBuffer\n";

            // One more check before leaving CS
            if (activeWriters > 0) {
                panic("Reader in CS while writer present");
            }
            if (activeReaders > 2) {
                panic("More than 2 readers in CS");
            }

            r_pc[id] = 7;   // move on to exit protocol
            event = true;
            break;

        case 7: // wait(mutexSem) for exit
            if (wait_int(mutexSem)) {
                cout << "Reader " << id << " got mutexSem to EXIT\n";
                r_pc[id] = 8;
                event = true;
            }
            break;

        case 8: {
            activeReaders--;
            readerCount--;
            cout << "Reader " << id << " EXIT CS. "
                 << "activeReaders=" << activeReaders
                 << ", readerCount=" << readerCount << "\n";

            if (readerCount == 0) {
                r_pc[id] = 9; // last reader -> signal(wrtSem)
            } else {
                r_pc[id] = 10;
            }
            event = true;
            break;
        }

        case 9: // last reader releases wrtSem
            signal_int(wrtSem);
            cout << "Reader " << id << " released wrtSem (last reader)\n";
            r_pc[id] = 10;
            event = true;
            break;

        case 10: // signal(mutexSem), signal(readSlots), loop or finish
            signal_int(mutexSem);
            signal_int(readSlots);
            cout << "Reader " << id
                 << " released mutexSem and readSlots\n";

            r_iters[id]++;
            if (r_iters[id] >= MAX_READER_ITERS) {
                cout << "Reader " << id << " DONE all iterations\n";
                r_pc[id] = -1; // finished
            } else {
                r_pc[id] = 0;  // start next iteration
            }
            event = true;
            break;

        default:
            break;
    }

    return event;
}

// =========================
//   Writer Process Step
//   returns true if an event happened
// =========================

bool step_writer(int id) {
    bool event = false;
    if (w_pc[id] == -1) return false;  // already finished

    switch (w_pc[id]) {
        case 0: // BROKEN: skip wait(wrtSem) to test panic
            if (1) {  // always succeed, never actually wait on semaphore
            cout << "Writer " << id << " (BROKEN) skips wrtSem wait\n";
                w_pc[id] = 1;
                event = true;
            }
            break;
        case 1: { // ENTER CS
            activeWriters++;
            cout << "Writer " << id << " ENTER CS. "
                 << "activeReaders=" << activeReaders
                 << ", activeWriters=" << activeWriters << "\n";

            cout << "Writer " << id << ": other readers inside = "
                 << activeReaders
                 << ", other writers inside = " << (activeWriters - 1) << "\n";

            if (activeReaders > 0) {
                panic("Writer in CS while readers present");
            }
            if (activeWriters > 1) {
                panic("More than one writer in CS");
            }

            // stay longer in CS:
            writerBusy[id] = 4;  // adjust cycles to control writer CS time

            w_pc[id] = 2;        // go to busy-loop state
            event = true;
            break;
        }

        case 2:  // busy loop inside CS, then actual write
            if (writerBusy[id] > 0) {
                cout << "Writer " << id << " busy-loop inside CS ("
                     << writerBusy[id] << " cycles left)\n";

                if (activeReaders > 0) {
                    panic("Writer in CS while readers present");
                }
                if (activeWriters > 1) {
                    panic("More than one writer in CS");
                }

                writerBusy[id]--;   // stay in state 2
                event = true;
                break;
            }

            // Busy time over: perform the actual "write"
            cout << "Writer " << id << " is WRITING...\n";

            // Example write pattern: unique-ish per writer & iteration
            {
                int value = (id + 1) * 100 + (w_iters[id] + 1);
                sharedBuffer = value;

                cout << "Writer " << id
                     << " writes value " << sharedBuffer
                     << " to sharedBuffer\n";
            }

            if (activeReaders > 0) {
                panic("Writer in CS while readers present");
            }
            if (activeWriters > 1) {
                panic("More than one writer in CS");
            }

            w_pc[id] = 3; // move to exit
            event = true;
            break;

        case 3: // EXIT CS
            activeWriters--;
            cout << "Writer " << id << " EXIT CS. activeWriters="
                 << activeWriters << "\n";
            signal_int(wrtSem);
            cout << "Writer " << id << " released wrtSem\n";

            w_iters[id]++;
            if (w_iters[id] >= MAX_WRITER_ITERS) {
                cout << "Writer " << id << " DONE all iterations\n";
                w_pc[id] = -1; // finished
            } else {
                w_pc[id] = 0;  // start next iteration
            }
            event = true;
            break;

        default:
            break;
    }

    return event;
}

// =========================
//   Scheduler Helpers
// =========================

bool all_finished() {
    for (int i = 0; i < N_READERS; i++)
        if (r_pc[i] != -1) return false;
    for (int i = 0; i < N_WRITERS; i++)
        if (w_pc[i] != -1) return false;
    return true;
}

// =========================
//   Main
// =========================

int main() {
    srand(static_cast<unsigned int>(time(nullptr)));

    // Initialize PCs, iteration counts, and busy counters
    for (int i = 0; i < N_READERS; i++) {
        r_pc[i]      = 0;
        r_iters[i]   = 0;
        readerBusy[i]= 0;
    }
    for (int i = 0; i < N_WRITERS; i++) {
        w_pc[i]      = 0;
        w_iters[i]   = 0;
        writerBusy[i]= 0;
    }

    cout << "Starting simulation .............\n";

    for (int step = 0; step < MAX_STEPS && !all_finished(); step++) {
        int pid = rand() % (N_READERS + N_WRITERS);
        bool event = false;

        if (pid < N_READERS) {
            int rid = pid;
            event = step_reader(rid);
            if (event) {
                cout << "\n=== Scheduler chose READER " << rid
                     << " at step " << step << " ===\n";
            }
        } else {
            int wid = pid - N_READERS;
            event = step_writer(wid);
            if (event) {
                cout << "\n=== Scheduler chose WRITER " << wid
                     << " at step " << step << " ===\n";
            }
        }
    }

    cout << "\nSimulation finished.\n";
    return 0;
}
