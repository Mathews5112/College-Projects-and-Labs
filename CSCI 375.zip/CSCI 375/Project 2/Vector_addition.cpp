// vector_addition.cpp
// Build: g++ -O2 -fopenmp vector_addition.cpp -o Vector_addition.exe
// Run:   ./Vector_addition.exe <n> <threads>

#include <cstdio>
#include <cstdlib>
#include <vector>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <omp.h>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <n> <threads>\n";
        return 1;
    }

    long long n = std::atoll(argv[1]);
    int threads = std::atoi(argv[2]);
    if (n <= 0 || threads <= 0) {
        std::cerr << "n and threads must be positive.\n";
        return 1;
    }

    // Init A[i]=i+1, B[i]=n-i  → C[i]=n+1
    std::vector<long long> A(n), B(n), C(n);
    for (long long i = 0; i < n; ++i) { A[i] = i + 1; B[i] = n - i; }

    // for reporting distribution + the per-thread output
    std::vector<long long> starts(threads, 0), ends(threads, 0), lens(threads, 0);
    std::vector<std::string> thread_output(threads);

    // Only allowed directive:
    #pragma omp parallel num_threads(threads)
    {
        int myid = omp_get_thread_num();
        int p    = omp_get_num_threads();

        // ---- required pseudocode indicated in the pdf ----
        long long mystart = (long long)myid * n / p;   // starting index
        long long myend   = mystart + n / p;           // ending index (exclusive)
        if (myid == p - 1) myend = n;                  // last thread takes remainder
        // -----------------------------

        starts[myid] = mystart;
        ends[myid]   = myend;
        lens[myid]   = myend - mystart;

        // Buffer this thread's lines to avoid interleaving on stdout
        std::ostringstream oss;
        oss << "Thread " << myid << " range [" << mystart << ", " << myend
            << ") length=" << (myend - mystart) << "\n";

        for (long long i = mystart; i < myend; ++i) {
            C[i] = A[i] + B[i];
            // Example line: "  1 + 10000 = 10001"
            oss << "  " << A[i] << " + " << B[i] << " = " << C[i] << "\n";
        }
        thread_output[myid] = oss.str();
    }

    // Print distribution + all additions, thread by thread
    std::cout << "Thread work distribution:\n";
    std::cout << "TID  begin     end    length\n";
    long long total = 0;
    for (int t = 0; t < threads; ++t) {
        std::cout << std::setw(3) << t << "  "
                  << std::setw(6) << starts[t] << "  "
                  << std::setw(7) << ends[t]   << "  "
                  << std::setw(7) << lens[t]   << "\n";
        total += lens[t];
    }
    std::cout << "Total length = " << total << " (n=" << n << ")\n\n";

    for (int t = 0; t < threads; ++t) {
        std::cout << thread_output[t];
    }

    // Quick correctness check
    long long expected = n + 1, bad = 0;
    for (long long i = 0; i < n; ++i) if (C[i] != expected) ++bad;
    std::cout << "\nCheck: " << (bad ? "FAIL" : "PASS — all C[i] == " + std::to_string(expected)) << "\n";
    return 0;
}
