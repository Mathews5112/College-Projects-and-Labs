#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>

#define MAX_BUFFER 1024
int *buffer;
int buffer_size;
int counter_limit;

int in = 0, out = 0;
int counter = 0;  // shared counter
int done = 0;     // signal to stop

DWORD WINAPI producer(LPVOID lpParam) {
    while (!done) {
        int next_produced = rand() % 100;

        // wait while buffer is full
        while (((in + 1) % buffer_size) == out && !done) { }

        if (done) break;

        buffer[in] = next_produced;
        in = (in + 1) % buffer_size;
        printf("Produced: %d\n", next_produced);

        counter++;
        if (counter >= counter_limit) {
            done = 1;
        }
    }
    return 0;
}

DWORD WINAPI consumer(LPVOID lpParam) {
    while (!done) {
        // wait while buffer is empty
        while (in == out && !done) { }

        if (done) break;

        int next_consumed = buffer[out];
        out = (out + 1) % buffer_size;
        printf("Consumed: %d\n", next_consumed);

        counter++;
        if (counter >= counter_limit) {
            done = 1;
        }
    }
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <buffer_size> <counter_limit>\n", argv[0]);
        return 1;
    }

    buffer_size = atoi(argv[1]);
    counter_limit = atoi(argv[2]);

    if (buffer_size > MAX_BUFFER) {
        printf("Max buffer size is %d\n", MAX_BUFFER);
        return 1;
    }

    buffer = (int*)malloc(sizeof(int) * buffer_size);
    srand((unsigned)time(NULL));

    HANDLE hProducer, hConsumer;

    hProducer = CreateThread(NULL, 0, producer, NULL, 0, NULL);
    hConsumer = CreateThread(NULL, 0, consumer, NULL, 0, NULL);

    WaitForSingleObject(hProducer, INFINITE);
    WaitForSingleObject(hConsumer, INFINITE);

    CloseHandle(hProducer);
    CloseHandle(hConsumer);

    free(buffer);
    printf("Main finished.\n");
    return 0;
}
