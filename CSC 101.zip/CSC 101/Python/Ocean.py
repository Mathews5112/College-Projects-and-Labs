rise_per_year = 1.6
rise = 0.0

print("years\tocean level rising")
print("---------------------------")

for years in range(25):
    rise += rise_per_year
    print(years + 1, '\t', format(rise, '.2f'))
