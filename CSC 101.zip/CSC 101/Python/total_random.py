# This program displays 4 random numbers
# in the range of 1 through 10.
# and calculates the results
import random

def prod():
    #get a random number
     number1 = random.randint(1, 10)
     number2 = random.randint(1, 10)
     number3 = random.randint(1, 10)
     number4 = random.randint(1, 10)
     print(number1, number2, number3, number4)
     total_value = number1 + number2 + number3 + number4
     print('The total value is', total_value)
        

#Call the main function
prod()    

    
