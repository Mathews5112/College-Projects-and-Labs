from random import randint

guessesTaken = 0
randomNumber = [str(randint(1, 9))  for _ in range(4)] # create list of random nums

while guessesTaken < 10: 
    guesses = list(input("Guess Number: ")) # create list of four digits
    check = "".join(["Y" if a==b else "N" for a,b in zip(guesses,randomNumber)])
    if check == "YYYY": # if check has four Y's we have a correct guess
        print("Congratulations, you are correct")
        break
    else:
        guessesTaken += 1 # else increment guess count and ask again
        print(check)
