def myfunc():
    global x
    x = 'fantastic'
    print(x)

myfunc()
