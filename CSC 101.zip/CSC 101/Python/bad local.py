# Definition of the main function
def main():
    get_name()
    print('Hello', name)          #This casues an error

# Defintion of the get_name funtion.
def get_name():
    name = input('Enter your name: ')

# Call the main funtion
main()
