for num in range(-5, 15, +2):
    print(num, '\n')
