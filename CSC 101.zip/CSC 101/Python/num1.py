num = 2

i = 0

while i < 5:   

    print("CSC101")   

    num = num + i   

    i = i + 1
