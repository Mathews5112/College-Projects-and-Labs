import random
import string


words = ['Jumble', 'Star', 'Candy', 'Wings', 'Power', 'String', 'Shopping', 'Blonde', 'Steak', 'Speakers', 'Case', 'Stubborn', 'Cat', 'Marker', 'Elevator', 'Taxi', 'Eight', 'Tomato', 'Penguin', 'Custard']


def jumble_word():
    word  = random.choice(word_list)
    jumble = ''.join(random.shuffle(list(word)))
    return word, jumble

def play(word_list):
    word, jumble = jumble_word(word_list)
    count = 0
    while True:
        print('Guess the word: {}'.format(jumble))
        guess = input('Enter your guess: ')
        guess += 1
        if word == guess:
            print('Correct! You got the word in {} tries!'.format(count))
            break
        else:
            print('Guess again! You have guessed {} times.'.format(count))


if __name__ == '__main__':
    play()
