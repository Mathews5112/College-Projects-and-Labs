#Ask the user to enter hours and hourly rate
hours = float(input("Enter your total hours: "))
hourly_rate = float(input("Enter your hourly rate: "))

gross_pay = hours * hourly_rate
print("Your gross pay is", gross_pay)

tax_rate = 20 / 100

total_tax = gross_pay * tax_rate
net_pay = gross_pay + total_tax

if net_pay < 200:
    print("Your net pay is", format(net_pay, '.2f'), "it is a small wage")

else:
    print("Your net pay is $", format(net_pay, '.2f'), sep='')
        



    
