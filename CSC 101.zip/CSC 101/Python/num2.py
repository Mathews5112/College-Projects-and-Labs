for num in range (14, 3, -1):
    print(num, '\n')

