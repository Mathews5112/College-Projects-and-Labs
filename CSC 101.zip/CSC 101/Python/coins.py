x = int(input("Enter a number less than 100: "))

quarters = int(x / 25)
leftover = x % 25
dimes = int(leftover / 10)

print("Quarters: ", quarters, "Dimes: ", dimes)
