# Assign the variables
total = 1
x = 0
# Ask the user to enter desired number
num = int(input("Please enter a whole number greater than 1: "))

# Calculate and display the factorial of the number
while x < num:
    total = total + num
    x = x + 1

print("Your total value is", total)
    
