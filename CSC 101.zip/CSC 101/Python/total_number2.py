def calculate():
    # Ask the user to enter the desired number
    i = int(input("Enter the desired integer: "))
    if i % 2 == 0:
        total = i * 2
        print("Your value is", total)
    else:
        total = i * 3
        print("Your value is", total)

calculate()        


    
