#Programing exercise 10

# Constants for the increase in tutuion per year,
# and the starting tuition amount.
Increase_per_year = 0.03
Starting_amount = 8000.0

#Declare a variable to store the tution.
tuition = Starting_amount

#Calculate the amount of increasment per year.
print ('Year\t Projected Tuition (per semester)')
print ('---------------------------------------')

for year in range(5):
    tuition += (tuition * Increase_per_year)
    print((year + 1), '\t', '$', \
          format(tuition, '.2f'))
