import random
import turtle
ans = 0
a = 0
guess = 0
b = 0
x = -250
y = 250
turtle.up()
turtle.goto(x,y)
turtle.down()
ans = random.randint(1,100)
turtle.write("Guess my random number between 1 to 100 ",font=("Arial",20,"bold"))
while a == 0:
    b = b + 1
    y = y - 20
    turtle.up()
    turtle.goto(x,y)
    turtle.down()
    guess = turtle.textinput("Guessing Game"," The number is ")
    guess = int(guess)
    if guess >100 or guess <1:
        turtle.up()
        turtle.goto(x,y)
        turtle.down()
        turtle.write("Out of the range!!!",font=("Arial",20,"old"))
        y = y-20
    elif guess > ans:
        turtle.up()
        turtle.goto(x,y)
        turtle.down()
        turtle.write("The number is too large!!!",font=("Arial",20,"bold"))
        turtle.down()
        y = y-20
    elif guess < ans:
        turtle.up()
        turtle.goto(x,y)
        turtle.down()
        turtle.write("The number is too small!!!",font=("Arial",20,"bold"))
        y = y-10
    if guess == ans:
        turtle.up()
        turtle.goto(x,y)
        turtle.down()
        turtle.write("Yes you are right!!!",font=("Arial",20,"bold"))
        y = y-20
        a = a + 1
turtle.up()
turtle.goto(x,y)
turtle.down()
turtle.write("Game is over!!!",font=("Arial",20,"bold"))
turtle.up()
turtle.goto(x,y-200)
turtle.down()
turtle.write ("You guessed",b,"times",font=("Arial",20,"bold"))


