# This program displays a random number
# in the range of 1 through 10.
import random

def main():
    x = 1
    while x <= 10:
        #get a random number
        number =  random.randint(1, 10)
        #Display the number.
        print('The number is', number)
        x = x + 1
#Call the main function
main()    
