def main():
    print('I have a message for you.')
    message()
    print('Goodbye!')

def message():
    print('I am Aurthur')
    print('King of the Britons.')

main()    
