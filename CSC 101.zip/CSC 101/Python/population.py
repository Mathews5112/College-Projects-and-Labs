# Question 13 chapter 11
# This program calculates the approximate size of a growing population
# It asks the user to enter the starting number of population
# the increasing rate of population and the number of days
# that it will grow


# Ask the user to enter the starting number of population
starting_p = int(input("Enter the number of starting population: "))

# Ask the user to enter the increasing rate of population by percentage
rate = float(input("Enter the increasing rate of population: "))

# Ask the user to enter the amount of days
days = int(input("Enter the total amount of days: "))

# print the table
print("Days\t Population")
print("------------------")

#Assign variables
rate = rate / 100
population = starting_p

#Calculate and print the population
for current_days in range(1, days+1):
    population = population + (rate * population)
    print(current_days, '\t', format(population, '.2f'))
