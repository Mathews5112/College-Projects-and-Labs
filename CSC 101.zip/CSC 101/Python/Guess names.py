var1="Almanzar"
var2="Carter"
var3="Graham"
var4="Maraj"
li=[var1,var2,var3,var4]
it_cor_guess=0
it_incor_guess=0
for i in range(0,6):
    inp1=input("Enter name of 1st musicians:")
    inp2=input("Enter name of 2nd musicians:")
    inp3=input("Enter name of 3rd musicians:")
    if((inp1 in li) and (inp2 in li) and (inp3 in li)):
        it_cor_guess=it_cor_guess+1
        print("Guess Correctly for iteratio {}".format(i))
    else:
        it_incor_guess=it_incor_guess+1
        print("In correct Guess for iteratio {}".format(i))
print("***************************************************")        
print("Number of correct Guess {}".format(it_cor_guess)) 
print("Number of In-correct Guess {}".format(it_incor_guess)) 
if(it_cor_guess>it_incor_guess):
    print("Correct")
elif(it_cor_guess<it_incor_guess):
    print("Incorrect")
else:
    print("Draw")
