# This program determines whether a bank customer
# qualifies for a loan.

Min_Salary = 30000 #The minimum annual salary
Min_Years = 2 #The minimum years on the job

#Get the customer's annual salary
salary = float(input('Enter your annual salary: '))

# Get the number of years on the current job
years_on_job = int(input('Enter the number of years employed: '))

#Determine whether the customer qualifies.
if salary >= Min_Salary:
    if years_on_job >= Min_Years:
        print('You qualify for the loan.')
    else:
        print('You must have been employed',
        'for at least', Min_Years, 'years to qualify.')
else:
    print('You must earn at least $',
          format(Min_Salary, ',.2f'),
          'per year to qulaify.', sep='')
