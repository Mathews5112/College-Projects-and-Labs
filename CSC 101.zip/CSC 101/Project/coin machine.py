#Ask user to enter the number of pennies
pennies = int(input("Enter the number of Pennies: "))

#Ask user to enter the number of nickels
nickels = int(input("Enter the number of Nickels: "))

#Ask user to enter the number of dimes
dimes = int(input("Enter the number of dimes: "))

#Ask user to enter the number of quarters
quarters = int(input("Enter the number of quarters: "))

#Convert nickels, dimes and quarters into pennies
Pennies_P = pennies
NICKLES_N = nickels * 5
DIMES_D = dimes * 10
QUARTERS_Q = quarters * 25

#Calculate the total sum of Pennies, nickels, dimes and quarters
total_values = Pennies_P + NICKELS_N + DIMES_D + QUARTERS_Q

#If the total values is equal to 100 print "Congratulations"
if total_values == 100:
    print("Congratulations!")

#If the total values is less than 100
elif total_values < 100:
    print("Your amount is less than $1")

#If the total values is greater than 100
else:
    print("Your amount is greater than $1")
