# Name: Sangram Mathews
# Course: CSC 101 (1100)
# Semester: Spring 2020
# Date: 04/20/2020

# This program asks the user to enter vehicle's speed
# and also asks to enter the duration of travel time
# then outputs the amount of distance traveled every hours.

# Ask user to enter the speed of vehicle
speed = float(input("Enter the speed of vehicle in mph: "))

# Ask user to enter the travel duration
time = int(input("Enter the duration  of travel in hours: "))

# Print the time\distance table
print('hour', '\tdistance(miles)')
print('--------------------------')

# Calculate the distance and print the results
for hour in range(1, time + 1):
    distance = speed * hour
    print(hour, '\t', format(distance, '.2f'))
