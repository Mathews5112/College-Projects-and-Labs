#Name: Sangram Mathews
#Course: CSC 101 (1100)
#Semester: Spring 2020
#Page 362, Q-12

#This program calculates the total amount of discount and
#the total amount of discounted price
#after applying the different percentange of discount ranging
#from 10%-40% according to the number of packages bought
#from the software company

retail_price = 99

#ask the user to enter the number of package/s
package_quantity = int(input("Enter the number of packages: "))

#If the number of packages bought is less than 10 there is no discount applied
if package_quantity < 10 :
    total_price0 = package_quantity * retail_price
    print('Your total price is $', format(total_price0, '.2f'), sep='')

#If the number of packages bought are in the range of 10-19
#and 10% discount is applied
elif 10 <= package_quantity <= 19 :
    total_price1 = retail_price * package_quantity
    Discount_1 = total_price1 * 0.1
    DPrice_1 = total_price1 - Discount_1
    print('Your total discount is $', format(Discount_1, '.2f'), sep='')
    print('And your total discounted price is $', format(DPrice_1, '.2f'), sep='')

#If the number of pacakages bought are in the range of 20-49
#and 20% discount is applied
elif 20 <= package_quantity <= 49 :
    total_price2 = retail_price * package_quantity
    Discount_2 = total_price2 * 0.2
    DPrice_2 = total_price2 - Discount_2
    print('Your total discount is $', format(Discount_2, '.2f'), sep='')
    print('And your total discounted price is $', format(DPrice_2, '.2f'), sep='')
    
#If the number of packages bought are in the range of 50-99
#and 30% discount is applied
elif 50 <= package_quantity <= 99 :
    total_price3 = retail_price * package_quantity
    Discount_3 = total_price3 * 0.3
    DPrice_3 = total_price3 - Discount_3
    print('Your total discount is $', format(Discount_3, '.2f'), sep='')
    print('And your total discounted price is $', format(DPrice_3, '.2f'), sep='')

#If the number of packages bought are 100 or more
#and 40% discount is applied

elif 100 <= package_quantity :
    total_price4 = retail_price * package_quantity
    Discount_4 = total_price4 * 0.4
    DPrice_4 = total_price4 - Discount_4
    print('Your total discount is $', format(Discount_4, '.2f'), sep='')
    print('And your total discounted price is $', format(DPrice_4, '.2f'), sep='')
    



    
    
