# Name: Sangram Mathews                                       Date: 4/17/2020
# Course: CSC 101 (1100)
# Semester: Spring 2020
# This program measures the BMI (Body Mass Index) of the user
# and also determines if the user is underweight, overweight or normal


# Ask the user to enter the weight in pounds (lbs)
weight = float(input('Enter your weight in pounds: '))

# Ask the user to enter the height in inches (in)
height = float(input('Enter your height in inches: '))

# Calculate the bmi using the formula and print the result
bmi = weight * 703/ (height **2)
print('Your BMI is ', format(bmi, '.1f'), sep='')

# If bmi is less than 18.5, the person is
# considered underweight
if bmi < 18.5:
    print('This is considered underweight.')
# If bmi is less than or equal to 25
# the weight of the person is considered normal
elif bmi <= 25:
    print('This is considered an optimal weight for your size.')

# Else if bmi is greater than 25, the person is considered overweight
else:
    print('This is considered overweight.')
    
