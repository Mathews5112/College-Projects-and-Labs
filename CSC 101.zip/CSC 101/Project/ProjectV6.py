#Name: Sangram Mathews
#      Ahron Scharman
#Project: Ver 6
#Course: CSC 101 (1100)
#Semester: Spring 2020
#Date: 05/05/2020
#--------------------------#
# This program lets the user to guess three names of Hip-Hop musicians
# sequentially out of four names that are in the variables. It gives the user
# 30 chances to guess the names and also it calculates the total number of
# correct and incorrect guesses. Then it decides if the user is "Correct",
# "Incorrect" or "Draw" based on the numbers of correct and incorrect guesses.


#creates 4 variables that contain the names of Hip-Hop musicians
var1 = 'Almanzar'
var2 = 'Carter'
var3 = 'Graham'
var4 = 'Maraj'

Total_correct_guess=0 #variable to keep a total of the correct guesses
Total_incorrect_guess=0 #variable to keep a total of the incorrect guesses

#a loop should repeat 30 times
for i in range(30):
    #variable to determine the number of times the user correctly guesses the three names 
    correct_guess=0 
    #variable to determine the number of times the user incorrectly guesses the three names 
    incorrect_guess=0

    #The user should guess (input) the first name in lowercase letters
    guess1=input('Guess the name of first musician in lowercase letters: ').lower() 
    #check if guess is correct or incorrect
    if guess1==var1.lower() or guess1==var2.lower() or guess1==var3.lower() or guess1==var4.lower():
        correct_guess=correct_guess+1
    else:
        incorrect_guess=incorrect_guess+1

    #The user should guess (input) the second name in lowercase letters
    guess2=input('Guess the name of second musician in lowercase letters: ').lower()
    #check if guess is correct or incorrect
    if guess2==var1.lower() or guess2==var2.lower() or guess2==var3.lower() or guess2==var4.lower():
        correct_guess=correct_guess+1
    else:
        incorrect_guess=incorrect_guess+1

    #The user should guess (input) the third name in lowercase letters
    guess3=input('Guess the name of third musician in lowercase letters: ').lower()
    #check if guess is correct or incorrect
    if guess3==var1.lower() or guess3==var2.lower() or guess3==var3.lower() or guess3==var4.lower():
        correct_guess=correct_guess+1
    else:
        incorrect_guess=incorrect_guess+1

# Calculate the total numbers of correct and incorrect guesses and display
    Total_correct_guess=Total_correct_guess+correct_guess
    Total_incorrect_guess=Total_incorrect_guess+incorrect_guess  
    print(correct_guess,'number of times you have guessed three names correctly.')
    print(incorrect_guess,'number of times you have guessed three names incorrectly.')

#After the loop performs all of its iteration, the program should display         
print('The number of correct guesses: ',Total_correct_guess) # the number of correct guesses
print('The number of incorrect guesses: ',Total_incorrect_guess) # the number of incorrect guesses
# "Correct" if the number of correct guesses is greater than the incorrect guesses
if Total_correct_guess>Total_incorrect_guess: 
    print('Correct') 
# "Incorrect" if the number of incorrect guesses is greater than the correct guesses
elif Total_incorrect_guess>Total_correct_guess: 
    print('Incorrect')
# "Draw" if the number of correct guesses is equal to the incorrect guesses
else:
    print('Draw') 
