# Name: Sangram Mathews
# Course: CSC 101 (1100)
# Semester : Spring 2020
# This program mixes one primary and one secondary color
# between red, blue and yellow and
# outputs the result.
# Chapter 10 question 7

# Ask user to enter the first primary color
color1 = input('Enter your first color: ')

# If the primary color is not equal to red, blue or yellow, it will print
# The error message
if color1 != 'red' and color1 != 'blue' and color1 != 'yellow':
    print('Error: That is not a primary color.')

# Ask user to enter the second primary color
else:
    color2 = input('Enter your second color: ')

# If the primary color is not equal to red, blue or yellow, it will print
# The error message
if color2 != 'red' and color2 != 'blue' and color2 != 'yellow':
    print('Error: That is not a primary color.')

# If first and second primary color is either red or yellow
# the result is going to be orange
else:
    if (color1 == 'red' and color2 == 'yellow') or (color1 == 'yellow' and color2 == 'red'):
        print('Mixing red and yellow creates orange.')

# If first and second primary color is either red or blue
# the result is going to be purple
    elif (color1 == 'red' and color2 == 'blue') or (color1 == 'blue' and color2 == 'red'):
        print('Mixing blue and red creates purple.')
    
# If first and second primary color is either yellow or blue
# the result is going to be green

    elif (color1 == 'yellow' and color2 == 'blue') or (color2 == 'blue' and color2 == 'yellow'):
        print('Mixing yellow and blue creates green.')

# Else mixing same first and second primary color
# creates the same unchanged color

    else:
        print('Mixing', color1 , 'and', color2 , 'yields', color1 , '!')
