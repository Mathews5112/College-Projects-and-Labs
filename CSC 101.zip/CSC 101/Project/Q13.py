# Ask the user to enter the weight in pounds
weight = float(input("Enter the weight of the object: "))

#Determine the shipping charges based on the following

#If the weight = 2 or less then rate = 1.50
if weight <= 2 :
    s_charges = weight * 1.50
    print("Your total shipping cost is $", format(s_charges, ',.2f'), sep='')

#If the weight > 2 and weight < 6, then rate = 3
elif weight >= 2 and weight <= 6 :
    s_charges = weight * 3
    print("Your total shipping cost is $", format(s_charges, ',.2f'), sep='')
    
#If the weight > 6 and weight < 10, then rate = 4
elif weight >= 6 and weight <= 10:
    s_charges = weight * 4
    print("Your total shipping cost is $", format(s_charges, ',.2f'), sep='')

#If the weight > 10, then rate = 4.75
elif weight > 10 :
    s_charges = weight * 4.75
    print("Your total shipping cost is $", format(s_charges, ',.2f'), sep='')
