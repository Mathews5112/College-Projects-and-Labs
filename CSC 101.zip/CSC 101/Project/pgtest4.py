# Ask the user to enter object's mass

mass = float(input("Enter the mass in kilograms: "))

#Calculate the weight of the object

weight = mass * 9.8

#If the weight is greater than 500 print "it is too heavy"
if weight > 500 :
    print('It is too heavy')

#Else if the weight is less than 100 print "it is too light"
elif weight < 100 :
    print('It is too light')
