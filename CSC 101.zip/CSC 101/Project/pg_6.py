# Name: Sangram Mathews
# Course: CSC 101 (1100)
# Semester: Spring 2020
# Page 360 Question 6 (Magic Dates)
# This program determines whether the month times the day equals the year.

# Ask user to enter the two digit of month
Month = int(input("Enter the two digit month: "))

# Ask user to enter the two digit of day
Day = int(input(" Enter the two digit day: "))

# Ask user to enter the last two digit of year
Year = int(input(" Enter the two digit year: "))

# If Year is equal to the multiplication of Month and Day
# It would output "The date is magic"
if Year == Month * Day :
    print ("The date is magic")
    
# If the condition doesn't meet
# It would output "The date is not magic"
else :
    print ("The date is not magic")
