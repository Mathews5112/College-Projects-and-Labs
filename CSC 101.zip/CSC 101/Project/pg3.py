print("Don't fear, I'm here")
print("I'm here!")
