# Name: Sangram Mathews
# Course: CSC 101 (1100)
# Semester: Spring 2020
# Date: 4/20/20

# This program calculates the amount of calories burnt
# from 10 minutes to 30 minutes
# on an increment of 5 minutes

# Assign the variables:
start_time = 10
end_time = 30
increment = 5
burn_rate = 4.2

# Print the table
print('minutes\tcalories')
print('------------------')


# Do the calculation and print the results
# In a minutes\calories table format
for minutes in range(start_time, end_time, increment):
    calories = minutes * burn_rate
    print(minutes, '\t', format(calories, '.1f'))
